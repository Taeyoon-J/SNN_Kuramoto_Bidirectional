"""Actual native4096-node CUDA admission; no reduced-resolution substitute."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from neutral_readout.head import NeutralRegionHead, objective
from readout_benchmark import runtime as r
from mod_benchmark import common as c
from snn_kuramoto_bidirectional import load_model
from joint_readout.model import configure, infer_features, gradients


def run(root, out):
    torch.set_num_threads(1)
    root, out = Path(root), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    c.immutable()
    assert torch.cuda.is_available()
    device = 'cuda:0'
    source, record = r.source(0, 'clevr', 'zero_shot')
    model = load_model(source, device=device)
    head = NeutralRegionHead(seed=251000).to(device)
    optimizer = configure(model, head)
    frozen = c.frozen_sha(model)
    train_id = int(r.ids_for('clevr', 'train', 256)[0])
    image = torch.from_numpy(r.read_rgb(root, 'clevr', 'train', np.array([train_id]))).to(device)
    truth = r.truth('clevr', 'train', np.array([train_id]))[0]
    cached = r.read_row(r.row_folder(root,'clevr','zero_shot',0), train_id, device)
    started = time.time()
    c.write(out/'smoke_progress.json', dict(stage='full_native_forward', image_id=train_id))
    f0, p0 = infer_features(model, image, inference_seed=251000+train_id)
    assert torch.equal(f0, cached['features']), 'forward feature cache equivalence failed'
    assert np.array_equal(p0, cached['all_support']), 'native partition equivalence failed'
    c.write(out/'smoke_progress.json', dict(stage='forward_passed_backward_started'))
    initial = {name:p.detach().clone() for name,p in model.named_parameters() if p.requires_grad}
    checks = []
    for step in range(2):
        optimizer.zero_grad(set_to_none=True)
        f, regions = infer_features(model, image, inference_seed=251000+train_id, live_tail_steps=64)
        if step == 0:
            assert torch.equal(f.detach(), f0), 'live-tail changes forward values'
            assert np.array_equal(regions, p0), 'live-tail changes partition'
        loss = objective(head(f, regions), truth)
        loss.backward()
        credit = gradients(optimizer)
        if step == 1:
            assert all(value>0 for value in credit.values()), ('disconnected gradient',credit)
        torch.nn.utils.clip_grad_norm_([p for g in optimizer.param_groups for p in g['params']],1.)
        optimizer.step()
        assert c.frozen_sha(model)==frozen, 'frozen core changed'
        checks.append(dict(step=step+1,loss=float(loss.detach()),gradient_L1=credit))
        c.write(out/'smoke_progress.json', dict(stage='backward',completed=step+1,checks=checks))
        del loss, f
    changed = {name:float((p.detach()-initial[name]).abs().max()) for name,p in model.named_parameters() if p.requires_grad}
    assert any(v>0 for k,v in changed.items() if k.startswith('encoder.'))
    assert any(v>0 for k,v in changed.items() if 'gamma_channel_proj' in k)
    state = dict(encoder=model.encoder.state_dict(),projection=model.wrapped.core.gamma_channel_proj.state_dict(),
                 head=head.state_dict(),optimizer=optimizer.state_dict())
    r.save(out/'smoke_resume.pt',state)
    reload = torch.load(out/'smoke_resume.pt',map_location=device,weights_only=True)
    model.encoder.load_state_dict(reload['encoder']); model.wrapped.core.gamma_channel_proj.load_state_dict(reload['projection'])
    head.load_state_dict(reload['head']); optimizer.load_state_dict(reload['optimizer'])
    assert {int(s['step'].item()) for s in optimizer.state.values()}=={2}
    preflight = {ds:c.preflight(ds,out/'preflight'/ds) for ds in c.DATASETS}
    result = dict(status='native_CUDA_joint_admission_passed',source_SHA256=c.sha(source),
                  native_grid=64,total_steps=1024,live_tail_steps=64,gradient_checks=checks,
                  encoder_projection_parameter_changes=changed,frozen_core_unchanged=True,
                  exact_source_forward_and_partition=True,optimizer_resume_steps=2,
                  benchmark_unchanged=c.immutable(),preflight=preflight,
                  peak_cuda_memory_bytes=torch.cuda.max_memory_allocated(),seconds=time.time()-started)
    c.write(out/'smoke_result.json',result)
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();run(args.root,args.output)
