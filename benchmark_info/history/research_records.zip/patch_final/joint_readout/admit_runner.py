"""Exercise the real training, validation, checkpoint and pixel-evaluation runner."""
import argparse
import gc
import json
from pathlib import Path
import torch
from mod_benchmark import common as c
from joint_readout.run import train,evaluate


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True)
    args=p.parse_args();root=Path(args.root);out=Path(args.output)
    assert out.name=='runner_admission'
    torch.set_num_threads(1)
    train(root,out,'clevr',0,'cuda:0',admission=True)
    gc.collect();torch.cuda.empty_cache()
    # Report-driven idempotent re-entry must not perform extra optimizer steps.
    train(root,out,'clevr',0,'cuda:0',admission=True)
    gc.collect();torch.cuda.empty_cache()
    evaluate(root,out,'multi_dsprites',0,'zero_shot',2,'cuda:0')
    report=json.loads((out/'training/clevr/seed0/report.json').read_bytes())
    scored=json.loads((out/'evaluation/multi_dsprites/zero_shot/seed0/result_2.json').read_bytes())
    assert report['optimizer_updates']==2 and report['admission_only']
    assert scored['count']==2 and scored['GT_used_for_prediction'] is False
    c.write(out/'passed.json',dict(status='real_training_validation_and_pixel_evaluation_passed',
            training_updates=2,validation_images=2,target_pixel_test_images=2,
            report_SHA256=c.sha(out/'training/clevr/seed0/report.json'),
            benchmark_unchanged=c.immutable()))
