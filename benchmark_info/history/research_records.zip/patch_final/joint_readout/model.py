"""Keep native252 forward operations; expose a bounded recurrent gradient path."""
from contextlib import contextmanager
import numpy as np
import torch
from neutral_readout.head import NeutralRegionHead, objective
from readout_benchmark.head import activity_features
from snn_kuramoto_bidirectional.sw240.rollout import late_rollout
from snn_kuramoto_bidirectional.sw240.capture import capture_source_coupling
from snn_kuramoto_bidirectional.sw240.correlation import native_component_rho_q
from snn_kuramoto_bidirectional.sw240.partition import foreground_induced_merge


@contextmanager
def graph_without_gradient(generator):
    """Recompute the image-specific graph, but omit its expensive derivative.

    Encoder credit passes through gamma -> sensory drive -> live dynamics.
    This is NOT a claim of differentiable partitioning or graph learning.
    """
    had = 'forward' in generator.__dict__
    previous = generator.__dict__.get('forward')
    original = generator.forward
    def forward(*args, **kwargs):
        with torch.no_grad():
            return original(*args, **kwargs)
    generator.forward = forward
    try:
        yield
    finally:
        if had:
            generator.forward = previous
        else:
            delattr(generator, 'forward')


def configure(model, head):
    model.requires_grad_(False)
    model.eval()
    model.encoder.requires_grad_(True)
    model.wrapped.core.gamma_channel_proj.requires_grad_(True)
    head.requires_grad_(True)
    return torch.optim.Adam([
        dict(name='encoder_base', params=model.encoder.base_encoder.parameters(), lr=3e-5),
        dict(name='encoder_context', params=model.encoder.context.parameters(), lr=3e-4),
        dict(name='sensory_projection', params=model.wrapped.core.gamma_channel_proj.parameters(), lr=3e-4),
        dict(name='mask_head', params=head.parameters(), lr=.003),
    ])


def infer_features(model, image, *, inference_seed, live_tail_steps=0):
    torch.manual_seed(int(inference_seed))
    if next(model.parameters()).is_cuda:
        torch.cuda.manual_seed(int(inference_seed))
    # Global evaluation no-grad is retained when live_tail_steps == 0.
    context = torch.enable_grad() if live_tail_steps else torch.no_grad()
    with context:
        gamma = model.encode(image)
        with graph_without_gradient(model.wrapped.core.graph_generator):
            trace, adjacency = capture_source_coupling(model.wrapped.core.kuramoto,
                lambda: late_rollout(model.wrapped, gamma, total_steps=1024,
                                     live_tail_steps=live_tail_steps))
        features = activity_features(trace)[0]
        # Match SW252's float16 activity cache, retaining identity gradient.
        features = features + (features.half().float() - features).detach()
    with torch.no_grad():
        rho, q = native_component_rho_q(trace['spikes'], trace['component_spikes'], settle=512)
        gain = float(model.wrapped.core.graph_generator.log_coupling_gain.exp().detach().cpu())
        regions = foreground_induced_merge(q[0].cpu().numpy().astype(np.float64),
            adjacency[0].cpu().numpy().astype(np.float64), gain,
            np.ones((64,64), dtype=np.int64), grid_shape=(64,64))['labels'].astype(np.int64)
    return features, regions


def gradients(optimizer):
    result = {}
    for group in optimizer.param_groups:
        grads = [p.grad for p in group['params'] if p.grad is not None]
        if any(not bool(torch.isfinite(g).all()) for g in grads):
            raise FloatingPointError('nonfinite gradient: ' + group['name'])
        result[group['name']] = sum(float(g.detach().abs().sum()) for g in grads)
    return result


def predict(model, head, image, inference_seed):
    features, regions = infer_features(model, image, inference_seed=inference_seed)
    return head.predict(features, regions)
