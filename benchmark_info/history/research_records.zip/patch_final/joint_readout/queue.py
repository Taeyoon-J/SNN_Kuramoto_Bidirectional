"""Persistent dependencies, one admitted job per GPU, no duplicate worker launch."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from mod_benchmark import common as c
from readout_benchmark.bootstrap import gpu_free


def plan():
    jobs=[]
    def add(key,action,ds,seed,dependencies=(),mode='zero_shot',count=360):
        jobs.append(dict(key=key,action=action,dataset=ds,seed=seed,
                         dependencies=list(dependencies),mode=mode,count=count))
    for s in range(3):add(f'clevr_train_s{s}','train','clevr',s)
    for s in range(3):add(f'clevr_eval_s{s}','evaluate','clevr',s,[f'clevr_train_s{s}'],count=320)
    for ds in c.DATASETS:
        for s in range(3):
            zero=f'{ds}_zero360_s{s}'
            add(zero,'evaluate',ds,s,[f'clevr_train_s{s}'])
    for ds in c.DATASETS:
        for s in range(3):
            adapt=f'{ds}_train_s{s}'
            add(adapt,'train',ds,s,[f'{ds}_zero360_s{s}'])
    for ds in c.DATASETS:
        for s in range(3):
            add(f'{ds}_fine360_s{s}','evaluate',ds,s,[f'{ds}_train_s{s}'],mode='finetune')
    for ds in c.DATASETS:
        for s in range(3):
            add(f'{ds}_zero1000_s{s}','evaluate',ds,s,[f'{ds}_zero360_s{s}'],count=1000)
            add(f'{ds}_fine1000_s{s}','evaluate',ds,s,[f'{ds}_fine360_s{s}'],mode='finetune',count=1000)
    return jobs


def run(root,out):
    root,out=Path(root),Path(out);out.mkdir(parents=True,exist_ok=True)
    lock=(out/'queue.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    admission=json.loads((out/'admission/smoke_result.json').read_bytes())
    assert admission['status']=='native_CUDA_joint_admission_passed'
    assert json.loads((out/'runner_admission/passed.json').read_bytes())['status']=='real_training_validation_and_pixel_evaluation_passed'
    c.immutable()
    jobs=plan();state_path=out/'queue_state.json'
    states=json.loads(state_path.read_bytes()) if state_path.exists() else [dict(job=j,status='queued') for j in jobs]
    assert [v['job'] for v in states]==jobs
    handles={};processes={}
    for index,v in enumerate(states):
        if v['status']=='running':
            # Do not adopt an unrelated recycled PID or silently duplicate work.
            proc=Path('/proc')/str(v['pid'])/'cmdline'
            if proc.exists() and b'joint_readout.run' in proc.read_bytes():
                raise RuntimeError('live workers from prior controller; inspect before adopting')
            v['status']='queued'
    logs=out/'logs';logs.mkdir(exist_ok=True)
    required_mb=max(12000,int(admission['peak_cuda_memory_bytes']/2**20*1.3)+1800)
    while True:
        for index,process in list(processes.items()):
            code=process.poll()
            if code is None:continue
            states[index].update(status='complete' if code==0 else 'failed',exit_code=code,finished_unix=time.time())
            for handle in handles.pop(index):handle.close()
            processes.pop(index)
            if code:
                c.write(out/'attention.json',dict(job=states[index],stderr=str(logs/f'{index:02d}.stderr')))
        complete={v['job']['key'] for v in states if v['status']=='complete'}
        if len(complete)==len(states):
            c.write(out/'all_jobs_complete.json',dict(status='all_scored_pending_independent_audit',jobs=len(states)))
            c.write(state_path,states);return
        free=gpu_free();busy={states[i]['physical_gpu'] for i in processes}
        for index,value in enumerate(states):
            if value['status']!='queued' or not set(value['job']['dependencies'])<=complete:continue
            available=[g for g in free if g not in busy and free[g]>=required_mb]
            if not available:break
            gpu=max(available,key=free.get);job=value['job']
            args=[sys.executable,'-u','-B','-m','joint_readout.run',job['action'],
                  '--root',str(root),'--output',str(out),'--dataset',job['dataset'],'--seed',str(job['seed']),
                  '--mode',job['mode'],'--count',str(job['count'])]
            stdout=(logs/f'{index:02d}.stdout').open('ab');stderr=(logs/f'{index:02d}.stderr').open('ab')
            process=subprocess.Popen(args,cwd=root/'code',env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu)),
                stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
            processes[index]=process;handles[index]=(stdout,stderr);busy.add(gpu)
            value.update(status='running',pid=process.pid,physical_gpu=gpu,started_unix=time.time())
        c.write(state_path,states)
        c.write(out/'queue_status.json',dict(completed=len(complete),total=len(states),running=len(processes),
                failed=sum(v['status']=='failed' for v in states),required_free_MB=required_mb,updated_unix=time.time()))
        time.sleep(30)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();run(args.root,args.output)
