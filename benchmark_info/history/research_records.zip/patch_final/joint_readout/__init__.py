"""SW0254: final-mask gradients to the SW240 encoder and sensory projection."""
