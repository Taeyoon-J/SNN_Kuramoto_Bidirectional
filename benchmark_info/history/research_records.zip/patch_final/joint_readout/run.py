"""Registered joint-mask training and immutable, resumable benchmark inference."""
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
import torch
from neutral_readout.head import NeutralRegionHead, objective
from readout_benchmark import runtime as r
from mod_benchmark import common as c
from snn_kuramoto_bidirectional import load_model
from snn_kuramoto_bidirectional.sw240.model import model_sha256
from joint_readout.model import configure, infer_features, gradients, predict


def fingerprint():
    return {p.name:c.sha(p) for p in sorted(Path(__file__).parent.glob('*.py'))}


def directory(out, dataset, seed):
    return Path(out)/'training'/dataset/f'seed{seed}'


def restore(model, head, state):
    model.encoder.load_state_dict(state['encoder'],strict=True)
    model.wrapped.core.gamma_channel_proj.load_state_dict(state['projection'],strict=True)
    head.load_state_dict(state['head'],strict=True)


def checkpoint(model, head, **extra):
    return dict(encoder=model.encoder.state_dict(),projection=model.wrapped.core.gamma_channel_proj.state_dict(),
                head=head.state_dict(),**extra)


def initial(root, out, dataset, seed, device):
    source, source_record = r.source(seed,'clevr','zero_shot')
    model=load_model(source,device=device)
    head=NeutralRegionHead(seed=251000+seed).to(device)
    if dataset!='clevr':
        parent=directory(out,'clevr',seed)/'best.pt'
        restore(model,head,torch.load(parent,map_location=device,weights_only=True))
        source_record=dict(source_record,joint_CLEVR_parent_SHA256=c.sha(parent))
    return model,head,source_record


def rng_seed(dataset, split, image_id):
    if split=='fixed320':return 193000+int(image_id)-1320
    if split=='test':return 193000+int(image_id)-7000
    offset=int(image_id)-1000 if dataset=='clevr' and split=='validation' else int(image_id)
    return 251000+offset


def validation(root, model, head, dataset, ids):
    images=r.read_rgb(root,dataset,'validation',ids)
    preds=[predict(model,head,torch.from_numpy(im[None]).to(next(model.parameters()).device),
                   rng_seed(dataset,'validation',i)) for i,im in zip(ids,images)]
    return r.values(preds,r.truth(dataset,'validation',ids))


def train(root, out, dataset, seed, device, admission=False):
    d=directory(out,dataset,seed);d.mkdir(parents=True,exist_ok=True)
    model,head,source=initial(root,out,dataset,seed,device)
    optimizer=configure(model,head)
    frozen=c.frozen_sha(model)
    ntrain,nval,updates=(2,2,2) if admission else (256,64,5120)
    ids=r.ids_for(dataset,'train',ntrain);vids=r.ids_for(dataset,'validation',nval)
    binding=dict(dataset=dataset,seed=seed,source=source,code=fingerprint(),benchmark=c.immutable(),
                 train_ids=ids.tolist(),validation_ids=vids.tolist(),epochs=1 if admission else 20,updates=updates,
                 total_steps=1024,live_tail_steps=64,graph_derivative=False,core_parameters_frozen=True,
                 final_mask_gradient_to_encoder=True,no_fixed_background=True,
                 adaptation_frequency_prephase=False)
    if (d/'report.json').exists():
        report=json.loads((d/'report.json').read_bytes());assert report['binding']==binding
        assert c.sha(d/'best.pt')==report['checkpoint_sha256'];return
    c.write(d/'binding.json',binding)
    first=0;history=[];best=-float('inf');epoch_losses=[];gradient_record={}
    if (d/'resume.pt').exists():
        state=torch.load(d/'resume.pt',map_location=device,weights_only=True)
        assert state['binding']==binding
        restore(model,head,state);optimizer.load_state_dict(state['optimizer'])
        first=state['completed_updates'];history=state['history'];best=state['best']
        epoch_losses=state['epoch_losses'];gradient_record=state['gradient_record']
    images=r.read_rgb(root,dataset,'train',ids);truth=r.truth(dataset,'train',ids)
    params=[p for g in optimizer.param_groups for p in g['params']]
    for step in range(first,updates):
        epoch,offset=divmod(step,ntrain)
        index=int(np.random.RandomState(251000+seed+10000*epoch).permutation(ntrain)[offset])
        optimizer.zero_grad(set_to_none=True)
        features,regions=infer_features(model,torch.from_numpy(images[index:index+1]).to(device),
            inference_seed=rng_seed(dataset,'train',ids[index]),live_tail_steps=64)
        loss=objective(head(features,regions),truth[index]);loss.backward()
        credit=gradients(optimizer)
        if step in (1,255,5119):
            assert all(v>0 for v in credit.values()), ('disconnected_joint_mask_gradient',credit)
            gradient_record[str(step+1)]=credit
        norm=torch.nn.utils.clip_grad_norm_(params,1.)
        if not bool(torch.isfinite(norm)):raise FloatingPointError('nonfinite joint gradient norm')
        optimizer.step();epoch_losses.append(float(loss.detach()))
        del features,loss
        if offset==ntrain-1:
            assert c.frozen_sha(model)==frozen
            score=validation(root,model,head,dataset,vids)
            history.append(dict(epoch=epoch+1,updates=step+1,loss=float(np.mean(epoch_losses)),validation=score))
            epoch_losses=[]
            if score['fg_ari']>best:
                best=score['fg_ari']
                r.save(d/'best.pt',checkpoint(model,head,binding=binding,epoch=epoch+1,
                    full_model_sha256=model_sha256(model)))
        if (step+1)%16==0 or step==updates-1:
            r.save(d/'resume.pt',checkpoint(model,head,binding=binding,optimizer=optimizer.state_dict(),
                completed_updates=step+1,history=history,best=best,epoch_losses=epoch_losses,
                gradient_record=gradient_record))
        c.write(d/'progress.json',dict(stage='joint_mask_training',completed_updates=step+1,total_updates=updates,
                epoch=epoch+1,loss=epoch_losses[-1] if epoch_losses else history[-1]['loss'],
                gradient_L1=credit,updated_unix=time.time()))
    assert c.frozen_sha(model)==frozen
    assert {int(v['step'].item()) for v in optimizer.state.values()}=={updates}
    c.write(d/'report.json',dict(status='joint_mask_training_complete',binding=binding,
        checkpoint_sha256=c.sha(d/'best.pt'),history=history,gradient_record=gradient_record,
        frozen_core_unchanged=True,unique_images=ntrain,optimizer_updates=updates,admission_only=admission))


def evaluate(root,out,dataset,seed,mode,count,device):
    source_dataset='clevr' if mode=='zero_shot' else dataset
    hp=directory(out,source_dataset,seed)/'best.pt'
    checkpoint_sha=c.sha(hp)
    d=Path(out)/'evaluation'/dataset/mode/f'seed{seed}';d.mkdir(parents=True,exist_ok=True)
    target=d/f'result_{count}.json'
    if target.exists():
        assert json.loads(target.read_bytes())['checkpoint_sha256']==checkpoint_sha;return
    model,head,_=initial(root,out,'clevr',seed,device)
    restore(model,head,torch.load(hp,map_location=device,weights_only=True))
    model.requires_grad_(False);head.requires_grad_(False)
    split='fixed320' if dataset=='clevr' else 'test'
    ids=r.ids_for(dataset,split,count)
    if dataset!='clevr':c.preflight(dataset,d/f'preflight_{count}')
    images=r.read_rgb(root,dataset,split,ids)
    native=[]
    rows=d/'rows';rows.mkdir(exist_ok=True)
    for image_id,image in zip(ids,images):
        path=rows/f'{int(image_id):06d}.npz';meta=path.with_suffix('.json')
        binding=dict(image_id=int(image_id),checkpoint_sha256=checkpoint_sha,
                     RGB_sha256=hashlib.sha256(image.tobytes()).hexdigest(),code=fingerprint())
        if meta.exists():
            saved=json.loads(meta.read_bytes());assert saved['binding']==binding and c.sha(path)==saved['sha256']
            with np.load(path,allow_pickle=False) as value:pred=value['native64'].copy()
        else:
            pred=predict(model,head,torch.from_numpy(image[None]).to(device),rng_seed(dataset,split,image_id))
            with path.open('wb') as f:np.savez_compressed(f,native64=pred)
            c.write(meta,dict(binding=binding,sha256=c.sha(path),GT_used_for_prediction=False))
        assert pred.shape==(64,64) and np.all(pred>0)
        native.append(pred)
        c.write(d/'progress.json',dict(completed=len(native),total=count,last_id=int(image_id),updated_unix=time.time()))
    native=np.stack(native)
    predictions=native if dataset=='clevr' else np.stack([c.prediction_grid(v,dataset) for v in native])
    saved=d/f'predictions_{count}.npz'
    with saved.open('wb') as f:np.savez_compressed(f,predictions=predictions,native64=native,ids=ids)
    # Only after predictions are fixed is evaluation truth loaded.
    if dataset=='clevr':
        truth=torch.from_numpy(r.truth(dataset,split,ids));pixel_pred=torch.from_numpy(predictions)
    else:
        truth=torch.load(c.DATA/f'pixel_labels_{dataset}.pt',map_location='cpu',weights_only=True,mmap=True)[torch.as_tensor(ids)]
        cells=c.benchmark_module('make_targets_grid');grid=c.DATASETS[dataset]
        iy,_=cells.cell_index(truth.shape[1],grid,'cpu');ix,_=cells.cell_index(truth.shape[2],grid,'cpu')
        pixel_pred=torch.from_numpy(predictions)[:,iy][:,:,ix]
    metrics=c.benchmark_module('evaluation').evaluate_patch_masks(pixel_pred,truth)
    with (d/f'scores_{count}.npz').open('wb') as f:
        np.savez_compressed(f,**{k:v.numpy() for k,v in metrics['per_image'].items()})
    c.write(target,dict(status='scored',dataset=dataset,mode=mode,seed=seed,count=count,
        metrics={k:float(metrics['mean'][k]) for k in r.KEYS},checkpoint_sha256=checkpoint_sha,
        prediction_sha256=c.sha(saved),benchmark_unchanged=c.immutable(),native_grid=64,
        raw_foreground_IoU_is_GT_area_fraction=True,GT_used_for_prediction=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['train','evaluate'])
    parser.add_argument('--root',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--dataset',required=True,choices=['clevr','multi_dsprites','tetrominoes'])
    parser.add_argument('--seed',type=int,required=True,choices=[0,1,2])
    parser.add_argument('--mode',default='zero_shot',choices=['zero_shot','finetune'])
    parser.add_argument('--count',type=int,default=360)
    parser.add_argument('--admission',action='store_true')
    args=parser.parse_args();torch.set_num_threads(1);c.immutable()
    if args.admission:
        assert Path(args.output).name=='runner_admission','admission artifacts must be isolated'
    if args.action=='train':train(Path(args.root),Path(args.output),args.dataset,args.seed,'cuda:0',args.admission)
    else:evaluate(Path(args.root),Path(args.output),args.dataset,args.seed,args.mode,args.count,'cuda:0')
