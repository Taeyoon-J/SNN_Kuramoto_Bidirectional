# SW0252: 배경 역할 비고정·영역 삭제 없는 결과

배경 전용 출력이나 최대 영역 삭제 없이 모든 영역을 유지한다. 정답의 배경 ID 0도
다른 정답 영역과 동등하게 Hungarian 매칭하여 최종 mask CE+Dice로 학습한다.
모든 출력 ID는 양수이며, 추론 시 정답·정답 물체 개수·배경 역할을 받지 않는다.
입력은 frozen 240의 실제 spike/membrane 144차원 활동과 전체 영역 graph partition이다.
240의 배경 제거 mask는 이 head의 입력으로 사용하지 않는다.

## CLEVR: 고정 320장, seed 0·1·2 평균

64×64 패치, ID 1320–1639. 재사용한 validation이며 미사용 test가 아니다.
같은 TRAIN256/VAL64, 20 epoch, seed당 Adam 5,120 update로 head만 학습했다.
240의 encoder/core를 새로 70,000장 학습한 실험이 아니다.

| 모델 | FG-ARI | Foreground IoU | Object IoU |
|---|---:|---:|---:|
| 원본 240 | 0.889187 | 0.754775 | 0.686438 |
| 251 residual background 보정 | 0.889629 | 0.784008 | 0.707530 |
| **252 배경 비고정, 모든 영역 유지** | **0.892326** | **0.211509†** | **0.738660** |

252의 seed별 FG-ARI는 0.894829 / 0.900362 / 0.881788이다.
240 대비 평균 차이는 +0.003139, paired-image 95% CI는 [+0.001978,+0.004578]이다.
세 seed 모두 개선됐고, FG-ARI 절대 감소 0.005 이내 조건을 통과했다.

## 추가 데이터셋: TEST360, 세 seed 평균

동일 ID 7000–7359의 360장이다. Multi-dSprites는 colored_on_colored 원본64 픽셀,
Tetrominoes는 보호된 modal grid32 규칙으로 변환하고 원본35 픽셀에 확장하여 평가했다.
마스크·평가 함수를 수정하지 않았다.

| 데이터셋 | 방식 | 기존 240 FG-ARI | 252 FG-ARI | 252 FG IoU† | 252 Object IoU |
|---|---|---:|---:|---:|---:|
| Multi-dSprites | 추가 학습 없음 | 0.697877 | 0.696620 | 0.094829 | 0.742679 |
| Multi-dSprites | 추가 학습 후 | 0.786001 | 0.787052 | 0.094829 | 0.795775 |
| Tetrominoes | 추가 학습 없음 | 0.616402 | **0.755965** | 0.244898 | 0.742691 |
| Tetrominoes | 추가 학습 후 | 0.799808 | **0.910496** | 0.244898 | 0.854954 |

추가 학습 후 Tetrominoes seed별 FG-ARI는 0.912249 / 0.914858 / 0.904382이다.
Multi-dSprites의 평균 변화는 작다. 이번 변경 조합은 Tetrominoes에서 큰 개선을 보였지만,
배경 삭제 규칙 하나만의 인과 효과를 분리한 결과는 아니다.

Zero-shot은 CLEVR에서 마스크 지도학습한 240+252 head의 전이이다. 비지도 결과가 아니다.
추가 학습 후에는 기존 SW0250의 검증된 encoder adaptation(TRAIN6000×10,
3,750 update)을 재사용하고, 그 위에 252 head를 TRAIN256×20, 5,120 update 추가 학습했다.
GT는 학습 loss 및 평가에만 쓰고 예측 생성에는 쓰지 않았다.

† 모든 영역을 양수 ID로 유지하므로 기존 metric의 `prediction != 0`은 이미지 전체가 된다.
따라서 raw Foreground IoU는 정답 전경 면적 비율과 같으며, 여기서는 전경/배경 검출 품질을
측정하지 않는다. 이 열을 240·251의 semantic foreground IoU와 직접 비교하지 않는다.
FG-ARI는 정답 전경에서 영역 구분을 측정하므로 동일 프로토콜 비교가 가능하다.
Object IoU는 원본 Hungarian 영역 매칭 점수이며 추론에서 배경을 제거한 결과가 아니다.

## 검증 및 남은 작업

- CLEVR 원본·수정 예측 1,920건 독립 재계산, 활동→mask 36건 재현 통과.
- 추가 데이터셋의 12개 조건 예측 4,320건 독립 재계산, 활동→mask 120건 재현 통과.
- 여섯 adaptation의 실제 5,120 update 및 초기 checkpoint binding 확인.
- Multi-dSprites TEST360의 단일 물체 이미지 86장은 모두 포함했으며, Tetrominoes는 0장이다.
- 보호된 benchmark 파일 및 원본 240 세 checkpoint SHA 불변 확인.
- 후속1,000장 평가와 최종 독립 audit도 완료했다. 기존360장 예측의 보존을 확인했으며,
  최종 결과는 [RESULTS_FINAL_KO.md](RESULTS_FINAL_KO.md)에 기록했다.

실행 증거: 비공개 SW0251_background_mask 기록의 `252_result.json`,
`252_benchmark_results_360.json`, `252_independent_original_audit.json`, `252_audit_360.json`.
