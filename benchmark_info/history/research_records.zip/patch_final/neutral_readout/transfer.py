"""SW0252 phase two: new-domain adaptation and unchanged pixel evaluation."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
import torch
from neutral_readout.head import NeutralRegionHead,objective
from readout_benchmark import runtime as r
from mod_benchmark import common as c


def adapt(root,out,dataset,seed,device):
    ids=r.ids_for(dataset,'train',256);valid=r.ids_for(dataset,'validation',64)
    folder=r.row_folder(root,dataset,'finetune',seed)
    for split,count in [('train',256),('validation',64)]:
        record=json.loads((folder/f'complete_{split}_{count}.json').read_bytes())
        assert record['ids']==r.ids_for(dataset,split,count).tolist()
        assert record['binding']['code']==r.fingerprint()
    initial=out/f'seed{seed}'/'best.pt';d=out/'adapted'/dataset/f'seed{seed}';d.mkdir(parents=True,exist_ok=True)
    _,source=r.source(seed,dataset,'finetune')
    binding=dict(dataset=dataset,seed=seed,ids=ids.tolist(),validation_ids=valid.tolist(),
        source=source,initial_sha256=c.sha(initial),head_code=c.sha(Path(__file__).with_name('head.py')),
        runner_code=c.sha(__file__),epochs=20,updates=5120,learning_rate=.003,
        no_background_slot=True,no_region_removed=True,TEST_used_for_training_or_selection=False)
    if (d/'report.json').exists():
        report=json.loads((d/'report.json').read_bytes());assert report['binding']==binding
        assert c.sha(d/'best.pt')==report['checkpoint_sha256'];return
    head=NeutralRegionHead(seed=251000+seed).to(device)
    start=torch.load(initial,map_location=device,weights_only=True);head.load_state_dict(start['head'])
    optimizer=torch.optim.Adam(head.parameters(),lr=.003)
    truth=r.truth(dataset,'train',ids);val_truth=r.truth(dataset,'validation',valid)
    first=0;history=[];best=-float('inf')
    if (d/'resume.pt').exists():
        state=torch.load(d/'resume.pt',map_location=device,weights_only=True);assert state['binding']==binding
        first=state['epoch'];history=state['history'];best=state['best']
        head.load_state_dict(state['head']);optimizer.load_state_dict(state['optimizer'])
    for epoch in range(first,20):
        head.train();losses=[]
        for index in np.random.RandomState(251000+seed+10000*epoch).permutation(len(ids)):
            row=r.read_row(folder,ids[index],device);optimizer.zero_grad(set_to_none=True)
            loss=objective(head(row['features'],row['all_support']),truth[index]);loss.backward()
            norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1.)
            if not bool(torch.isfinite(norm)) or float(norm)<=0:raise FloatingPointError('disconnected adaptation gradient')
            optimizer.step();losses.append(float(loss.detach()))
        head.eval();pred=[]
        for image_id in valid:
            row=r.read_row(folder,image_id,device);pred.append(head.predict(row['features'],row['all_support']))
        score=r.values(pred,val_truth)
        history.append(dict(epoch=epoch+1,updates=(epoch+1)*256,loss=float(np.mean(losses)),validation=score))
        if score['fg_ari']>best:
            best=score['fg_ari'];r.save(d/'best.pt',dict(head=head.state_dict(),binding=binding,epoch=epoch+1))
        r.save(d/'resume.pt',dict(head=head.state_dict(),optimizer=optimizer.state_dict(),binding=binding,
            epoch=epoch+1,history=history,best=best))
        c.write(out/'transfer_progress.json',dict(stage='adaptation',dataset=dataset,seed=seed,epoch=epoch+1,total_epochs=20))
    c.write(d/'report.json',dict(binding=binding,history=history,checkpoint_sha256=c.sha(d/'best.pt'),best_validation_FGARI=best))


def cache_ready(root,count):
    for ds in c.DATASETS:
        for mode in ('zero_shot','finetune'):
            for seed in range(3):
                path=r.row_folder(root,ds,mode,seed)/f'complete_test_{count}.json'
                if not path.exists():return False
                record=json.loads(path.read_bytes())
                assert record['ids']==r.ids_for(ds,'test',count).tolist()
                assert record['binding']['code']==r.fingerprint()
    return True


def score(root,out,count,device):
    target=out/f'benchmark_results_{count}.json'
    if target.exists():return
    metric=c.benchmark_module('evaluation');cells=c.benchmark_module('make_targets_grid')
    records=[]
    # Freeze all twelve predictions before loading target TEST masks.
    for ds in c.DATASETS:
        for mode in ('zero_shot','finetune'):
            for seed in range(3):
                hp=out/f'seed{seed}'/'best.pt' if mode=='zero_shot' else out/'adapted'/ds/f'seed{seed}'/'best.pt'
                state=torch.load(hp,map_location=device,weights_only=True)
                head=NeutralRegionHead().to(device);head.load_state_dict(state['head']);head.eval()
                folder=r.row_folder(root,ds,mode,seed);ids=r.ids_for(ds,'test',count);native=[]
                for image_id in ids:
                    row=r.read_row(folder,image_id,device);native.append(head.predict(row['features'],row['all_support']))
                native=np.stack(native);assert np.all(native>0)
                pred=np.stack([c.prediction_grid(v,ds) for v in native]);assert np.all(pred>0)
                d=out/'results'/ds/mode/f'seed{seed}';d.mkdir(parents=True,exist_ok=True)
                path=d/f'predictions_{count}.npz'
                with path.open('wb') as stream:np.savez_compressed(stream,predictions=pred,native64=native,ids=ids)
                if count==1000:
                    with np.load(d/'predictions_360.npz',allow_pickle=False) as earlier:
                        assert np.array_equal(earlier['predictions'],pred[:360]) and np.array_equal(earlier['native64'],native[:360])
                records.append(dict(dataset=ds,mode=mode,seed=seed,path=str(path),prediction_sha256=c.sha(path),head_sha256=c.sha(hp),
                    GT_used_for_prediction=False,no_background_removed=True,source=json.loads((folder/'binding.json').read_bytes())))
    c.write(out/f'prediction_protocol_{count}.json',dict(count=count,records=records,no_fixed_background=True))
    results={}
    for ds,grid in c.DATASETS.items():
        ids=r.ids_for(ds,'test',count)
        truth=torch.load(c.DATA/f'pixel_labels_{ds}.pt',map_location='cpu',weights_only=True,mmap=True)[torch.as_tensor(ids)]
        iy,_=cells.cell_index(truth.shape[1],grid,'cpu');ix,_=cells.cell_index(truth.shape[2],grid,'cpu')
        single=int(sum(len(torch.unique(v[v!=0]))==1 for v in truth))
        for mode in ('zero_shot','finetune'):
            rows=[]
            for seed in range(3):
                d=out/'results'/ds/mode/f'seed{seed}';c.preflight(ds,d/f'preflight_{count}')
                record=next(v for v in records if v['dataset']==ds and v['mode']==mode and v['seed']==seed)
                assert c.sha(record['path'])==record['prediction_sha256']
                with np.load(record['path'],allow_pickle=False) as blob:pred=torch.from_numpy(blob['predictions'].copy())
                scored=metric.evaluate_patch_masks(pred[:,iy][:,:,ix],truth)
                row=dict(seed=seed,metrics={k:float(scored['mean'][k]) for k in r.KEYS},single_object_images=single,
                    valid_count={k:int(v) for k,v in scored['valid_count'].items()})
                with (d/f'scores_{count}.npz').open('wb') as stream:np.savez_compressed(stream,**{k:v.numpy() for k,v in scored['per_image'].items()})
                c.write(d/f'result_{count}.json',row);rows.append(row)
            results[f'{ds}/{mode}']=dict(per_seed=rows,mean={k:float(np.mean([v['metrics'][k] for v in rows])) for k in r.KEYS})
    c.write(target,dict(status='all_twelve_scored',experiment='SW0252',count=count,results=results,
        benchmark_unchanged=c.immutable(),no_background_slot=True,no_background_removed=True,
        IoU_interpretation='All groups retained with positive IDs: raw foreground IoU is full-image foreground, not semantic foreground detection.',
        extra_training='finetune reuses verified SW0250 encoder TRAIN6000x10 then neutral head TRAIN256x20',created_unix=time.time()))


def run(root,out):
    torch.set_num_threads(1);torch.cuda.set_per_process_memory_fraction(.12,0);device='cuda:0'
    root=Path(root);out=Path(out);assert (out/'result.json').exists()
    c.immutable()
    for ds in c.DATASETS:
        for seed in range(3):adapt(root,out,ds,seed,device)
    torch.cuda.empty_cache()
    for count in (360,1000):
        while not cache_ready(root,count):
            c.write(out/'transfer_progress.json',dict(stage='waiting_for_registered_source_cache',count=count,existing_workers_preserved=True))
            time.sleep(45)
        score(root,out,count,device)
    c.write(out/'transfer_complete.json',dict(status='twelve_conditions_scored_pending_independent_audit',created_unix=time.time()))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    run(a.root,a.output)
