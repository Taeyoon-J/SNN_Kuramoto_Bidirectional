"""SW0253: faithful frozen SW0165 native32 transfer, no target-data training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import numpy as np
import torch

ROOT=Path('/Data0/kevinswk/patch_v2_sw')
SHARED=ROOT/'collaborative_testing/generated/SW0251_background_mask/code'
OLD=ROOT/'collaborative_testing/generated/SW0250_mod_benchmark'
sys.path[:0]=[str(ROOT),str(ROOT/'collaborative_test'),str(ROOT/'snn_kuramoto_bidirectional')]
from collaborative_test.SW_0130_phase_state_integration import run as sw130
from collaborative_test.SW_0134_native_spike_binding.rollout import late_rollout
from collaborative_test.SW_0135_native32_spike_binding.foundation import load_native32_foundation
from collaborative_test.SW_0136_native32_transfer import evaluate as sw136
from collaborative_test.SW_0143_native32_selective_geodesic import geodesic_operator
from collaborative_test.SW_0162_connected_signed_partition import preflight as source
from collaborative_test.SW_0164_foreground_preserving_partition import foreground_signed as solver
sys.path.append(str(SHARED))
from mod_benchmark import common as c

DATASETS=('multi_dsprites','tetrominoes')
KEYS=('fg_ari','foreground_iou','matched_object_iou')


def load(seed,device):
    path,manifest_path,manifest,pool,ids,sha=sw130.source_contract(seed)
    assert manifest['ground_truth_used_for_training'] is False
    found=load_native32_foundation(seed,device,verify_rgb_assets=False)
    found.encoder.eval().requires_grad_(False);found.wrapped.eval().requires_grad_(False)
    geodesic_operator.install_operator(found.wrapped.core.graph_generator,'T')
    identity=dict(seed=seed,checkpoint=str(path),sha256=sha,manifest_sha256=c.sha(manifest_path),
        source_core_ground_truth_used_for_training=False,encoder_sha256=c.sha(sw130.ENCODER_SOURCE),
        statistics_sha256=c.sha(sw130.FEATURE_STATS),source_model_state=source._source_state_digest(found),
        native_grid=32,steps=1024,settle=512,target_dataset_updates=0,
        foreground_rule='unchanged SW165 Source-T support; largest component heuristic retained')
    return found,identity


@torch.no_grad()
def predict(found,rgb):
    image=torch.from_numpy(np.asarray(rgb[None]).copy()).to(next(found.encoder.parameters()).device)
    gamma=found.encode(image)
    trace,a=source.capture_source_coupling(found.wrapped.core.kuramoto,
        lambda:late_rollout(found.wrapped,gamma,total_steps=1024,live_tail_steps=0))
    source._trace_check(trace);source._validate_actual_A(a)
    q=source._actual_q(trace);support=sw136._qcc_labels(trace)[0]
    gain=float(found.wrapped.core.graph_generator.log_coupling_gain.exp().detach().cpu())
    labels=solver.foreground_induced_merge(q[0].cpu().numpy().astype(np.float64),
        a[0].cpu().numpy().astype(np.float64),gain,support,grid_shape=(32,32))['labels'].astype(np.int64)
    assert labels.shape==(32,32) and np.all(labels>=0) and np.array_equal(labels>0,support>0)
    return labels


def admission(out,device):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);c.immutable();torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.12,0)
    for ds in DATASETS:c.preflight(ds,out/'admission_preflight'/ds)
    rgb=np.load(sw130.VAL_RGB,mmap_mode='r');rows=[]
    for seed in range(3):
        found,identity=load(seed,device);torch.cuda.reset_peak_memory_stats()
        if seed==1:
            folder=ROOT/'collaborative_test/SW_0164_foreground_preserving_partition/results_archive/predictions_20261014/foreground_induced_seed1'
        else:
            folder=ROOT/f'collaborative_test/SW_0165_foreground_partition_replication/results_archive/predictions_20261014/foreground_induced_seed{seed}'
        with np.load(folder/'predictions.npz',allow_pickle=False) as saved:expected=saved['labels'][0].copy()
        replay=predict(found,np.asarray(rgb[0]))
        assert np.array_equal(replay,expected),'SW165 replay differs; do not launch target benchmark'
        for ds in DATASETS:
            x=np.load(OLD/'inputs'/ds/'train128.npy',mmap_mode='r')[0]
            actual=predict(found,np.asarray(x));assert actual.shape==(32,32)
        assert source._source_state_digest(found)==identity['source_model_state']
        rows.append(dict(identity=identity,CLEVR_first_mask_exact=True,two_actual_TRAIN_forwards_passed=True,
            torch_peak_reserved_bytes=torch.cuda.max_memory_reserved()))
        del found;torch.cuda.empty_cache()
    report=dict(status='actual_three_seed_SW165_replay_and_two_dataset_admission_passed',rows=rows,
        benchmark_unchanged=c.immutable(),code_sha256=c.sha(__file__),target_GT_opened=False)
    c.write(out/'admission.json',report);print(json.dumps(report))


def worker(out,seed,device):
    out=Path(out);torch.set_num_threads(1);torch.cuda.set_per_process_memory_fraction(.12,0)
    admitted=json.loads((out/'admission.json').read_bytes());assert admitted['code_sha256']==c.sha(__file__)
    found,identity=load(seed,device);assert identity==admitted['rows'][seed]['identity']
    inputs={}
    for ds in DATASETS:
        binding=json.loads((OLD/'inputs'/ds/'binding.json').read_bytes())
        path=OLD/'inputs'/ds/'test128.npy'
        assert c.sha(path)==binding['upscaled']['test']['sha256']
        inputs[ds]=np.load(path,mmap_mode='r');assert inputs[ds].shape==(1000,128,128,3)
    seedout=out/f'seed{seed}';seedout.mkdir(exist_ok=True)
    binding=dict(source=identity,code_sha256=c.sha(__file__),target_training=False,
        datasets=DATASETS,source_checkpoint_unchanged=True)
    # JSON tuples normalize to lists; freeze the exact serialized binding.
    binding=json.loads(json.dumps(binding))
    if (seedout/'binding.json').exists():assert json.loads((seedout/'binding.json').read_bytes())==binding
    else:c.write(seedout/'binding.json',binding)
    for count in (360,1000):
        for ds in DATASETS:
            d=seedout/ds;d.mkdir(exist_ok=True);rowsdir=d/'rows';rowsdir.mkdir(exist_ok=True)
            rows=[]
            for i in range(count):
                path=rowsdir/f'{i:04d}.npz';meta=path.with_suffix('.json')
                rgb=np.asarray(inputs[ds][i]);rgbsha=hashlib.sha256(rgb.tobytes()).hexdigest()
                if meta.exists():
                    record=json.loads(meta.read_bytes())
                    assert record['RGB_sha256']==rgbsha and record['source_sha256']==identity['sha256'] and record['image_id']==7000+i
                    assert record['row_sha256']==c.sha(path)
                    with np.load(path,allow_pickle=False) as v:labels=v['labels'].copy()
                else:
                    labels=predict(found,rgb)
                    temporary=path.with_suffix('.tmp')
                    with temporary.open('wb') as stream:np.savez_compressed(stream,labels=labels)
                    os.replace(temporary,path)
                    c.write(meta,dict(image_id=7000+i,RGB_sha256=rgbsha,source_sha256=identity['sha256'],row_sha256=c.sha(path),target_GT_used=False))
                rows.append(labels)
                if i%10==0 or i==count-1:c.write(d/'progress.json',dict(completed=i+1,total=count,seed=seed,dataset=ds))
            labels=np.stack(rows);path=d/f'predictions_{count}.npz'
            with path.open('wb') as stream:np.savez_compressed(stream,labels=labels,image_ids=np.arange(7000,7000+count))
            if count==1000:
                with np.load(d/'predictions_360.npz',allow_pickle=False) as earlier:assert np.array_equal(earlier['labels'],labels[:360])
            assert source._source_state_digest(found)==identity['source_model_state']
            c.write(d/f'protocol_{count}.json',dict(binding=binding,count=count,prediction_sha256=c.sha(path),GT_used_for_prediction=False,
                native_grid=32,scoring='expand native32 cells to original pixels; no original truth resampling'))
    assert c.sha(identity['checkpoint'])==identity['sha256'];c.immutable()
    c.write(seedout/'complete.json',dict(status='all_predictions_frozen',source_unchanged=True))


def score(out,count):
    out=Path(out);metric=c.benchmark_module('evaluation');cells=c.benchmark_module('make_targets_grid')
    records=[]
    for seed in range(3):
        for ds in DATASETS:
            d=out/f'seed{seed}'/ds;p=json.loads((d/f'protocol_{count}.json').read_bytes())
            assert p['GT_used_for_prediction'] is False and c.sha(d/f'predictions_{count}.npz')==p['prediction_sha256']
            records.append(dict(seed=seed,dataset=ds,protocol=p))
    c.write(out/f'prediction_protocol_{count}.json',dict(records=records,all_six_frozen_before_target_truth=True))
    result={}
    for ds in DATASETS:
        truth=torch.load(c.DATA/f'pixel_labels_{ds}.pt',map_location='cpu',weights_only=True,mmap=True)[7000:7000+count]
        iy,_=cells.cell_index(truth.shape[1],32,'cpu');ix,_=cells.cell_index(truth.shape[2],32,'cpu')
        oracle=cells.mask_cells(truth,32)[0]
        ceiling=metric.evaluate_patch_masks(oracle[:,iy][:,:,ix],truth)
        singles=int(sum(len(torch.unique(v[v!=0]))==1 for v in truth));rows=[]
        for seed in range(3):
            d=out/f'seed{seed}'/ds;c.preflight(ds,d/f'preflight_{count}')
            with np.load(d/f'predictions_{count}.npz',allow_pickle=False) as v:
                assert np.array_equal(v['image_ids'],np.arange(7000,7000+count));pred=v['labels'].copy()
            assert pred.shape==(count,32,32)
            expanded=torch.from_numpy(pred)[:,iy][:,:,ix]
            scored=metric.evaluate_patch_masks(expanded,truth)
            row=dict(seed=seed,metrics={k:float(scored['mean'][k]) for k in KEYS},
                single_object_images=singles,valid_count={k:int(v) for k,v in scored['valid_count'].items()},
                mean_groups=float(np.mean([len(np.unique(v[v>0])) for v in pred])))
            with (d/f'scores_{count}.npz').open('wb') as stream:np.savez_compressed(stream,**{k:v.numpy() for k,v in scored['per_image'].items()})
            c.write(d/f'result_{count}.json',row);rows.append(row)
        result[ds]=dict(per_seed=rows,mean={k:float(np.mean([v['metrics'][k] for v in rows])) for k in KEYS},
            native32_pixel_FGARI_ceiling=float(ceiling['mean']['fg_ari']))
    c.write(out/f'results_{count}.json',dict(status='all_six_zero_shot_scored',experiment='SW0253',source_model='SW0165',count=count,
        native_grid=32,target_training=False,source_supervision='verified no ground-truth core training; original reconstruction encoder unchanged',
        results=result,benchmark_unchanged=c.immutable(),created_unix=time.time()))


def coordinator(out):
    out=Path(out)
    for count in (360,1000):
        while not all((out/f'seed{s}'/ds/f'protocol_{count}.json').exists() for s in range(3) for ds in DATASETS):
            launch=json.loads((out/'launch.json').read_bytes())
            for row in launch['workers']:
                proc=Path('/proc')/str(row['pid'])
                if (out/f"seed{row['seed']}"/'complete.json').exists():continue
                assert proc.stat().st_uid==os.getuid() and b'unsupervised_run.py' in proc.joinpath('cmdline').read_bytes()
                assert proc.joinpath('stat').read_text().rsplit(')',1)[1].split()[0]!='Z','worker ended without complete record'
            time.sleep(30)
        if not (out/f'results_{count}.json').exists():score(out,count)
    c.write(out/'complete.json',dict(status='all_requested_unsupervised_zero_shot_scored_pending_audit'))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--seed',type=int,choices=(0,1,2))
    parser.add_argument('--admit',action='store_true');parser.add_argument('--coordinator',action='store_true');a=parser.parse_args()
    if a.admit:admission(a.output,'cuda:0')
    elif a.coordinator:coordinator(a.output)
    else:worker(a.output,a.seed,'cuda:0')
