"""Same data, steps and mask loss; vary only the prior/affinity logit calibration."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import torch
from readout_benchmark import runtime as r
from readout_benchmark.head import mask_objective
from mod_benchmark import common as c
from .head import RefinementHead,VARIANTS


def fingerprint():
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob('*.py'))}


def folder(archive,ds,mode,seed,variant,count):
    return Path(archive)/'refinement'/ds/mode/f'seed{seed}'/f'{variant}_TRAIN{count}'


def load_head(path,device='cpu'):
    saved=torch.load(path,map_location=device,weights_only=True)
    assert saved['head_type']=='calibrated_activity_refinement'
    head=RefinementHead(saved['variant'],seed=251000+saved['binding']['seed']).to(device)
    head.load_state_dict(saved['head'],strict=True);head.eval()
    return head


def train(archive,ds,mode,seed,variant,count,validation_count,device='cuda:0',initial=None):
    if not 0<count<=(70000 if ds=='clevr' else 6000):raise ValueError('TRAIN count outside declared split')
    if not 0<validation_count<=(320 if ds=='clevr' else 1000):raise ValueError('validation would cross a reserved split')
    root=folder(archive,ds,mode,seed,variant,count);root.mkdir(parents=True,exist_ok=True)
    cache=r.row_folder(archive,ds,mode,seed)
    ids=r.ids_for(ds,'train',count);vi=r.ids_for(ds,'validation',validation_count)
    assert len(ids)==count and set(ids).isdisjoint(vi)
    for i in [*ids,*vi]:assert (cache/f'{int(i):06d}.json').exists()
    binding=dict(dataset=ds,mode=mode,seed=seed,variant=variant,TRAIN_count=count,validation_count=validation_count,
        ids=ids.tolist(),validation_ids=vi.tolist(),epochs=20,learning_rate=.003,
        source_cache=json.loads((cache/'binding.json').read_bytes()),source_code=fingerprint(),base_code=r.fingerprint(),
        initial_sha256=c.sha(initial) if initial else None,prior_strength=VARIANTS[variant][0],metric_gain=VARIANTS[variant][1],
        core_encoder_frozen=True,final_mask_loss='unchanged v1 CE+Dice+.25 BG BCE+.25 pair+.1 partition anchor')
    if (root/'report.json').exists():
        old=json.loads((root/'report.json').read_bytes());assert old['binding']==binding
        assert c.sha(root/'best.pt')==old['checkpoint_sha256'];return old
    if (root/'binding.json').exists():assert json.loads((root/'binding.json').read_bytes())==binding
    else:c.write(root/'binding.json',binding)
    head=RefinementHead(variant,seed=251000+seed).to(device)
    if initial:
        old=torch.load(initial,map_location=device,weights_only=True)
        assert old['variant']==variant;head.load_state_dict(old['head'],strict=True)
    opt=torch.optim.Adam(head.parameters(),lr=.003);history=[];best=-float('inf');start=0
    if (root/'resume.pt').exists():
        old=torch.load(root/'resume.pt',map_location=device,weights_only=True);assert old['binding']==binding
        head.load_state_dict(old['head'],strict=True);opt.load_state_dict(old['optimizer'])
        history=old['history'];best=old['best'];start=old['epoch']
    truth=r.truth(ds,'train',ids);validation=r.truth(ds,'validation',vi)
    base=[r.read_row(cache,i,'cpu')['baseline'] for i in vi]
    for epoch in range(start,20):
        head.train();losses=[];actual_ids=[]
        for index in np.random.RandomState(251000+seed+10000*epoch).permutation(count):
            row=r.read_row(cache,ids[index],device);opt.zero_grad(set_to_none=True)
            loss,_=mask_objective(head(row['features'],row['baseline'],row['all_support']),truth[index],row['baseline'])
            loss.backward();norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1.)
            assert bool(torch.isfinite(loss) and torch.isfinite(norm)) and float(norm)>0
            opt.step();losses.append(float(loss.detach()));actual_ids.append(int(ids[index]))
        head.eval();score,pred=r.evaluate_rows(cache,vi,validation,head,device)
        changed=sum(int(((a>0)&(b>0)&(a!=b)).sum()) for a,b in zip(base,pred))
        history.append(dict(epoch=epoch+1,updates=(epoch+1)*count,loss=float(np.mean(losses)),actual_TRAIN_ids=actual_ids,
                            validation=score,positive_group_reassignments=changed,scale=float(head.residual_scale.detach())))
        if score['fg_ari']>best:
            best=score['fg_ari'];r.save(root/'best.pt',dict(head=head.state_dict(),head_type='calibrated_activity_refinement',
                variant=variant,binding=binding,epoch=epoch+1,validation=score,positive_group_reassignments=changed))
        r.save(root/'resume.pt',dict(head=head.state_dict(),optimizer=opt.state_dict(),binding=binding,
                                  history=history,epoch=epoch+1,best=best))
        c.write(root/'progress.json',history[-1])
    selected=torch.load(root/'best.pt',map_location='cpu',weights_only=True)
    report=dict(status='refinement_training_complete',binding=binding,best_epoch=selected['epoch'],validation=selected['validation'],
                positive_group_reassignments=selected['positive_group_reassignments'],updates=20*count,history=history,
                checkpoint_sha256=c.sha(root/'best.pt'),checkpoint=str(root/'best.pt'),
                mask_loss_backpropagation='readout only',TEST_used_for_training_or_selection=False)
    c.write(root/'report.json',report);return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--archive',required=True)
    parser.add_argument('--dataset',default='clevr',choices=('clevr','multi_dsprites','tetrominoes'))
    parser.add_argument('--mode',default='zero_shot',choices=('zero_shot','finetune'))
    parser.add_argument('--seed',type=int,choices=(0,1,2),required=True)
    parser.add_argument('--variant',choices=tuple(VARIANTS),required=True)
    parser.add_argument('--count',type=int,default=64);parser.add_argument('--validation-count',type=int,default=16)
    parser.add_argument('--initial');a=parser.parse_args()
    torch.set_num_threads(1);torch.cuda.set_device(0);torch.cuda.set_per_process_memory_fraction(.05,0)
    result=train(a.archive,a.dataset,a.mode,a.seed,a.variant,a.count,a.validation_count,initial=a.initial)
    print(json.dumps({k:v for k,v in result.items() if k not in ('history','binding')}),flush=True)
