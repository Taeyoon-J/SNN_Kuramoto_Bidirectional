"""Retain exact initial hard masks while allowing supervised object reassignment."""
import math
import torch
from torch.nn import functional as F
from readout_benchmark.head import ActivityMaskHead,FEATURES,candidate_masks

VARIANTS={'control':(4.,1.),'soft_prior':(1.,1.),'strong_metric':(4.,16.)}


class RefinementHead(ActivityMaskHead):
    def __init__(self,variant='control',*,seed=251000):
        if variant not in VARIANTS:raise ValueError('registered refinement variant required')
        super().__init__(background_only=False,seed=seed)
        self.variant=variant
        self.prior_strength,self.metric_gain=VARIANTS[variant]

    def forward(self,features,baseline,proposals):
        if features.ndim!=2 or features.shape[1]!=FEATURES or not bool(torch.isfinite(features).all()):
            raise ValueError('finite actual [N,144] activity features required')
        base=torch.as_tensor(baseline,device=features.device,dtype=torch.long)
        prop=torch.as_tensor(proposals,device=features.device,dtype=torch.long)
        if base.numel()!=len(features) or prop.shape!=base.shape:raise ValueError('aligned prediction grids required')
        masks,prior=candidate_masks(base,prop,features=features)
        prior=prior*(self.prior_strength/4.)
        z=F.normalize(self.embedding(features),dim=-1)
        seeds=F.normalize(masks.float()@z/masks.sum(1,keepdim=True).clamp_min(1),dim=-1)
        positive=prior[1:]+(self.metric_gain*self.residual_scale)*(seeds@z.T)
        return torch.cat([prior[:1]+self.background(features).T,positive],dim=0)

    def reassignment_bound(self):
        """If bound <= prior, no old positive group can lose to another positive."""
        return 2*self.metric_gain*abs(float(self.residual_scale.detach()))
