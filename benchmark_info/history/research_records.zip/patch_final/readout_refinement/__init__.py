"""SW0251 controlled readout variants; frozen activity caches remain reusable."""
