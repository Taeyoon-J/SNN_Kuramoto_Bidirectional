import unittest
import numpy as np
import torch
from readout_benchmark.head import ActivityMaskHead,mask_objective
from .head import RefinementHead,VARIANTS


class RefinementAdmission(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1);torch.manual_seed(9)
        self.x=torch.randn(64,144)
        self.base=torch.zeros(8,8,dtype=torch.long);self.base[1:4,1:4]=1;self.base[5:7,4:7]=2
        self.prop=torch.arange(64).reshape(8,8)//8+1

    def test_initial_hard_masks_preserved_for_all_variants(self):
        for variant in VARIANTS:
            head=RefinementHead(variant)
            np.testing.assert_array_equal(head.predict(self.x,self.base,self.prop),self.base.numpy())

    def test_control_logits_and_gradients_exactly_match_v1(self):
        old=ActivityMaskHead(seed=251000);new=RefinementHead('control',seed=251000)
        before=old(self.x,self.base,self.prop);after=new(self.x,self.base,self.prop)
        torch.testing.assert_close(before,after,rtol=0,atol=0)
        before.square().sum().backward();after.square().sum().backward()
        for (a,p),(b,q) in zip(old.named_parameters(),new.named_parameters()):
            self.assertEqual(a,b);torch.testing.assert_close(p.grad,q.grad,rtol=0,atol=0)

    def test_actual_mask_loss_gradient_for_each_refinement(self):
        truth=self.base.clone();truth[0,0]=1
        for variant in ('soft_prior','strong_metric'):
            head=RefinementHead(variant)
            loss,_=mask_objective(head(self.x,self.base,self.prop),truth,self.base);loss.backward()
            self.assertGreater(float(head.residual_scale.grad.abs()),0)
            self.assertTrue(all(torch.isfinite(p.grad).all() for p in head.parameters() if p.grad is not None))

    def test_reassignment_is_no_longer_barred_at_observed_scale(self):
        # The observed v1 best scale .56 cannot overcome prior4 (bound1.12).
        for variant in ('soft_prior','strong_metric'):
            head=RefinementHead(variant)
            with torch.no_grad():head.residual_scale.fill_(.56)
            self.assertGreater(head.reassignment_bound(),head.prior_strength)


if __name__=='__main__':unittest.main()
