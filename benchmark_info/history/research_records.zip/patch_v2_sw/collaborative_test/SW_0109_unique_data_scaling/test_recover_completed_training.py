import unittest
import math
from pathlib import Path

from recover_completed_training import (dataset_provenance, locate_failed_attempt,
                                       validate_history, validate_history_rows)


class RecoveryAuditTests(unittest.TestCase):
    def test_preserves_historical_unused_dataset_argument_separately(self):
        launch = {"dataset_path": "/Data0/kevinswk/patch_v2_sw/datasets/object_centric_data/clevr_10-full.hdf5"}
        original, registered = dataset_provenance(launch)
        self.assertEqual(original, launch["dataset_path"])
        self.assertEqual(registered, "/Data0/kevinswk/datasets/object_centric_data/clevr_10-full.hdf5")
        self.assertNotEqual(original, registered)

    def test_rejects_reconstructed_or_corrected_historical_argv(self):
        with self.assertRaises(ValueError):
            dataset_provenance({"dataset_path": "/Data0/kevinswk/datasets/object_centric_data/clevr_10-full.hdf5"})

    def test_uses_registered_unprefixed_task_id_and_exact_output(self):
        output = Path("/models/seed0_N10000")
        task = {"task_id": "train_seed0_N10000", "experiment": "SW0109",
                "stage": "train", "seed": 0, "size": 10000,
                "output": str(output)}
        state = {"tasks": [task], "pending": [], "active": {}, "attempts": [
            {"task_id": task["task_id"], "return_code": 1,
             "validated": False, "failure": "task_failed_validation", "log": "/logs/task.log"}]}
        found, attempt = locate_failed_attempt(state, task, 10000, output)
        self.assertEqual(found["task_id"], "train_seed0_N10000")
        self.assertEqual(attempt["return_code"], 1)

    def test_rejects_interruption_even_if_exit_code_is_one(self):
        output = Path("/models/seed0_N2500")
        task = {"task_id": "train_seed0_N2500", "experiment": "SW0109",
                "stage": "train", "seed": 0, "size": 2500,
                "output": str(output)}
        state = {"tasks": [task], "pending": [task["task_id"]], "active": {}, "attempts": [
            {"task_id": task["task_id"], "return_code": 1,
             "validated": False, "failure": "foreign_owner_appeared"}]}
        with self.assertRaises(ValueError):
            locate_failed_attempt(state, task, 2500, output)

    def test_rejects_incomplete_history(self):
        with self.assertRaises(FileNotFoundError):
            validate_history(Path("missing.json"), 2500)

    def test_accepts_exact_history_and_rejects_gap_or_nonfinite_value(self):
        rows = [{"update": i, "loss": 1.0, "primary": 0.5,
                 "positive_actual_spike_product_unweighted": 0.1,
                 "gradient_norm_preclip": 0.25} for i in range(1, 4376)]
        self.assertEqual(len(validate_history_rows(rows)), 4375)
        rows[100]["update"] = 102
        with self.assertRaises(ValueError):
            validate_history_rows(rows)
        rows[100]["update"] = 101
        rows[101]["loss"] = math.nan
        with self.assertRaises(ValueError):
            validate_history_rows(rows)


if __name__ == "__main__":
    unittest.main()
