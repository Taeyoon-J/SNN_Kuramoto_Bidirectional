"""Audit and optionally package a SW0113 post-training metadata failure.

This never trains, performs a forward pass, or overwrites existing outputs.
Default mode is dry-run.  ``--write`` is intentionally gated by a complete
artifact, queue, preflight, source, and log audit; it writes recovery audit,
then the normal manifest, then the completion marker last.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import sys

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run as experiment

ORIGINAL_DEPLOYED_RUNNER_SHA256 = "08a06572a429fe78888184e66852e5e845c79713b342d70e524be4960cb6ca91"
METADATA_FIXED_RUNNER_SHA256 = "500c30573cb43e6070d45ee8db919aff8838b1ce3aef0efebc5d42feb5aa83ab"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def finite_number(value) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(float(value))


def locate_failed_attempt(state, task, size: int, output: Path):
    """Bind launch-evidence task metadata to the SW0113 attempt row."""
    if (not isinstance(task, dict) or task.get("stage") != "train"
            or task.get("experiment") != "SW0109" or task.get("seed") != 0
            or task.get("size") != size
            or Path(task.get("output", "")).resolve() != output.resolve()):
        raise ValueError("launch evidence task metadata does not match requested output")
    task_id = task.get("task_id")
    if not isinstance(task_id, str) or not task_id:
        raise ValueError("registered task has no task_id")
    state_tasks = state.get("tasks")
    if not isinstance(state_tasks, list):
        raise ValueError("archived SW0113 state has no registered task list")
    registered_rows = [row for row in state_tasks if isinstance(row, dict)
                       and row.get("task_id") == task_id]
    if len(registered_rows) != 1:
        raise ValueError(f"expected one archived task row for {task_id}, found {len(registered_rows)}")
    actual = registered_rows[0]
    for field in ("task_id", "experiment", "stage", "seed", "size", "output"):
        if actual.get(field) != task.get(field):
            if field == "output" and Path(actual.get(field, "")).resolve() == output.resolve() == Path(task.get(field, "")).resolve():
                continue
            raise ValueError(f"launch task metadata differs from archived state field {field}")
    active = state.get("active", {})
    if (task_id in active or any(row.get("task_id") == task_id
                                 for row in active.values() if isinstance(row, dict))):
        raise ValueError("failed task is still active")
    pending = state.get("pending", [])
    if task_id in pending or any(isinstance(row, dict) and row.get("task_id") == task_id
                                 for row in pending):
        raise ValueError("task remains pending in the archived queue state")
    attempts = [row for row in state.get("attempts", []) if row.get("task_id") == task_id]
    if len(attempts) != 1:
        raise ValueError(f"expected one terminal attempt for {task_id}, found {len(attempts)}")
    attempt = attempts[0]
    failure_text = str(attempt.get("failure", "")).lower()
    if (attempt.get("return_code") != 1 or attempt.get("validated") is not False
            or attempt.get("foreign_owners_during") or attempt.get("interruption_reason")
            or any(term in failure_text for term in ("foreign", "owner", "interrupt", "resource"))):
        raise ValueError("attempt is not the isolated metadata KeyError failure")
    return task, attempt


def validate_preflight(pf, *, seed: int, source_sha: str, source_manifest_sha: str,
                       source_path: Path, runner_sha: str,
                       gamma_sha: str, gamma_manifest_sha: str,
                       encoder_sha: str, preprocessing_sha: str):
    if (pf.get("status") != "passed" or pf.get("seed") != seed
            or pf.get("source_core_sha256") != source_sha
            or pf.get("source_manifest_sha256") != source_manifest_sha
            or Path(pf.get("source_core_path", "")).resolve() != source_path.resolve()
            or pf.get("runner_sha256") != runner_sha
            or pf.get("train_gamma_sha256") != gamma_sha
            or pf.get("train_gamma_manifest_sha256") != gamma_manifest_sha
            or pf.get("encoder_sha256") != encoder_sha
            or pf.get("feature_preprocessing_sha256") != preprocessing_sha
            or pf.get("batch_size") != 16 or pf.get("steps") != 64
            or pf.get("settle") != 32 or pf.get("ground_truth_used") is not False
            or set(pf.get("pool_checks", {})) != {str(n) for n in experiment.SIZES}):
        raise ValueError("archived preflight top-level contract does not match original runner")
    checks = {}
    for size in experiment.SIZES:
        check = pf["pool_checks"][str(size)]
        pool, order = experiment.training_order(seed, size)
        batches = check.get("batches", [])
        if (check.get("status") != "passed" or check.get("pool_size") != size
                or check.get("unique_images_in_pool") != size
                or check.get("graph_bitwise_unchanged") is not True or len(batches) != 4
                or check.get("pool_sha256") != hashlib.sha256(
                    np.asarray(sorted(pool), dtype="<i8").tobytes()).hexdigest()):
            raise ValueError(f"preflight pool contract failed for size {size}")
        for index, batch in enumerate(batches):
            expected_ids = order[index * 16:(index + 1) * 16].tolist()
            expected_rows = experiment.row_indices(expected_ids).tolist()
            if (batch.get("global_ids") != expected_ids or batch.get("gamma_rows") != expected_rows
                    or batch.get("finite_gradient") is not True
                    or batch.get("throwaway_adam_update") is not True
                    or not finite_number(batch.get("loss"))
                    or not finite_number(batch.get("primary_loss"))
                    or not finite_number(batch.get("positive_actual_spike_product_unweighted"))
                    or not finite_number(batch.get("gradient_norm_preclip"))
                    or batch["gradient_norm_preclip"] <= 0):
                raise ValueError(f"preflight batch {index} failed for size {size}")
        checks[str(size)] = {"pool_sha256": check["pool_sha256"],
                             "ordered_first64_exact": True, "four_batches_valid": True,
                             "graph_bitwise_unchanged": True}
    return checks


def validate_history_rows(history):
    if not isinstance(history, list) or len(history) != experiment.UPDATES:
        raise ValueError("history must contain exactly 4,375 updates")
    for index, row in enumerate(history, 1):
        keys = ("loss", "primary", "positive_actual_spike_product_unweighted", "gradient_norm_preclip")
        if row.get("update") != index or any(not finite_number(row.get(key)) for key in keys):
            raise ValueError(f"invalid/nonfinite history row {index}")
        if row["gradient_norm_preclip"] <= 0:
            raise ValueError(f"nonpositive gradient norm at update {index}")
        expected = row["primary"] + 5.0 * row["positive_actual_spike_product_unweighted"]
        if abs(row["loss"] - expected) > 2e-5 * max(1.0, abs(expected)):
            raise ValueError(f"recorded objective decomposition mismatch at update {index}")
    return history


def validate_history(path: Path, size: int):
    return validate_history_rows(read_json(path))


def validate_core(path: Path, source_path: Path, *, device="cpu"):
    source = experiment.load_core(0, source_path, device)
    recovered = experiment.load_core(0, source_path, device)
    state = torch.load(path, map_location=device, weights_only=True)
    if set(state) != set(source.state_dict()):
        raise ValueError("recovered core state keys differ from strict source architecture")
    recovered.load_state_dict(state, strict=True)
    trainable = {name for name, parameter in recovered.named_parameters() if parameter.requires_grad}
    changed = []
    for key, tensor in state.items():
        if not torch.isfinite(tensor).all():
            raise ValueError(f"nonfinite checkpoint tensor: {key}")
        differs = not torch.equal(tensor, source.state_dict()[key])
        if differs and key not in trainable:
            raise ValueError(f"nontrainable parameter or buffer changed: {key}")
        if differs:
            changed.append(key)
    if not changed:
        raise ValueError("no eligible core parameter changed from source")
    return changed


def check_error_log(path: Path, expected_sha: str):
    if sha(path) != expected_sha:
        raise ValueError("attempt log SHA differs from immutable launch evidence")
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    if "KeyError: '4096'" not in text or "exposure_counts[str(BATCH*256)]" not in text:
        raise ValueError("attempt log does not prove the expected post-training metadata KeyError")
    return {"sha256": expected_sha, "exact_post_training_keyerror": True}


def dataset_provenance(launch):
    """Separate the historical CLI argument from the cache's real dataset."""
    original_arg = "/Data0/kevinswk/patch_v2_sw/datasets/object_centric_data/clevr_10-full.hdf5"
    registered_path = "/Data0/kevinswk/datasets/object_centric_data/clevr_10-full.hdf5"
    if launch.get("dataset_path") != original_arg:
        raise ValueError("historical SW0113 dataset argv differs from archived launch evidence")
    return original_arg, registered_path


def audit_and_manifest(args):
    size = args.size
    out = Path(args.output_dir)
    state_path, pf_path = Path(args.archived_master_state), Path(args.archived_preflight)
    old_runner, log_path = Path(args.original_runner_backup), Path(args.error_log)
    launch_path = Path(args.launch_evidence)
    for path in (state_path, pf_path, old_runner, log_path, launch_path,
                 out / "core.pt", out / "prefix_256_core.pt", out / "history.json",
                 out / "progress.json"):
        if not path.is_file():
            raise FileNotFoundError(path)
    if (out / "manifest.json").exists() or (out / "TRAINING_COMPLETED").exists():
        raise FileExistsError("refusing to overwrite an existing training manifest/marker")
    state, launch = read_json(state_path), read_json(launch_path)
    task, attempt = locate_failed_attempt(state, launch.get("registered_task"), size, out)
    state_sha, old_runner_sha, pf_sha = sha(state_path), sha(old_runner), sha(pf_path)
    if (launch.get("archived_state_sha256") != state_sha
            or launch.get("task_id") != task["task_id"]
            or Path(launch.get("archived_attempt_log_path", "")).resolve() != log_path.resolve()
            or Path(launch.get("original_attempt_log_path", "")).resolve()
               != Path(attempt.get("log", "")).resolve()
            or launch.get("attempt_log_sha256") != sha(log_path)
            or launch.get("original_runner_sha256") != old_runner_sha
            or launch.get("preflight_sha256") != pf_sha
            or launch.get("attempt_return_code") != 1):
        raise ValueError("launch evidence does not bind the archived SW0113 failure inputs")
    source_item, source_path, source_manifest_path = experiment.source_entry(0)
    source_sha = sha(source_path)
    if source_sha != source_item["core_sha256"]:
        raise ValueError("registered seed0 source hash no longer matches source audit")
    if (old_runner_sha != ORIGINAL_DEPLOYED_RUNNER_SHA256
            or sha(HERE / "run.py") != METADATA_FIXED_RUNNER_SHA256
            or launch.get("patched_runner_sha256") != METADATA_FIXED_RUNNER_SHA256):
        raise ValueError("current metadata-only runner differs from launch evidence")
    if launch.get("original_runner_sha256") != old_runner_sha:
        raise ValueError("original runner backup SHA mismatch")
    gamma_path = Path(launch["train_gamma_path"])
    gamma_manifest_path = Path(launch["train_gamma_manifest_path"])
    gamma_sha, gamma_manifest_sha = sha(gamma_path), sha(gamma_manifest_path)
    if (launch.get("train_gamma_sha256") != gamma_sha
            or launch.get("train_gamma_manifest_sha256") != gamma_manifest_sha):
        raise ValueError("training gamma files differ from the immutable launch evidence")
    original_dataset_arg, registered_dataset_path = dataset_provenance(launch)
    registered_dataset = Path(registered_dataset_path)
    if not registered_dataset.is_file():
        raise ValueError("canonical registered HDF5 dataset is unavailable for provenance")
    expected_argv = [sys.executable, str(HERE / "run.py"), "--stage", "train",
        "--size", str(size), "--output", str(out), "--seed", "0",
        "--train-gamma", str(gamma_path), "--train-manifest", str(gamma_manifest_path),
        "--val-gamma", str(launch["val_gamma_path"]),
        "--val-manifest", str(launch["val_gamma_manifest_path"]),
        "--dataset", original_dataset_arg, "--device", "cuda:0"]
    if launch.get("argv") != expected_argv:
        raise ValueError("actual command does not reconstruct from the registered SW0113 adapter contract")
    experiment.gamma_contract(gamma_path, gamma_manifest_path, validation=False)
    preflight = read_json(pf_path)
    preflight_checks = validate_preflight(preflight, seed=0, source_sha=source_sha,
        source_manifest_sha=sha(source_manifest_path), source_path=source_path,
        runner_sha=old_runner_sha, gamma_sha=gamma_sha,
        gamma_manifest_sha=gamma_manifest_sha,
        encoder_sha=experiment.sha(experiment.ENCODER),
        preprocessing_sha=experiment.sha(experiment.FEATURE_STATS))
    log_check = check_error_log(log_path, launch["attempt_log_sha256"])
    history = validate_history(out / "history.json", size)
    changed = validate_core(out / "core.pt", source_path)
    prefix = torch.load(out / "prefix_256_core.pt", map_location="cpu", weights_only=True)
    source = experiment.load_core(0, source_path, "cpu")
    prefix_model = experiment.load_core(0, source_path, "cpu")
    prefix_model.load_state_dict(prefix, strict=True)
    trainable = {name for name, parameter in source.named_parameters() if parameter.requires_grad}
    if set(prefix) != set(source.state_dict()):
        raise ValueError("prefix checkpoint keys differ from strict source architecture")
    prefix_changed = []
    for key, tensor in prefix.items():
        if not torch.isfinite(tensor).all():
            raise ValueError(f"nonfinite prefix tensor: {key}")
        differs = not torch.equal(tensor, source.state_dict()[key])
        if differs and key not in trainable:
            raise ValueError(f"prefix nontrainable parameter or buffer changed: {key}")
        if differs:
            prefix_changed.append(key)
    if not prefix_changed:
        raise ValueError("prefix checkpoint is incompatible or has no trained parameters")
    pool, order = experiment.training_order(0, size)
    counts = experiment.exposure_count_map(order)
    order_sha = hashlib.sha256(np.asarray(order, dtype="<i8").tobytes()).hexdigest()
    pool_sha = hashlib.sha256(np.asarray(sorted(pool), dtype="<i8").tobytes()).hexdigest()
    progress = read_json(out / "progress.json")
    if (progress.get("seed") != 0 or progress.get("unique_images") != size
            or progress.get("update") != 4352 or progress.get("total_updates") != 4375):
        raise ValueError("last periodic progress must be the authentic update-4352 record")
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    input_hashes = {str(p): sha(p) for p in (state_path, pf_path, old_runner, launch_path,
                      log_path, out / "core.pt", out / "prefix_256_core.pt", out / "history.json",
                      out / "progress.json", source_path, source_manifest_path,
                      gamma_path, gamma_manifest_path, HERE / "run.py", Path(__file__),
                      experiment.AUDIT, experiment.ENCODER, experiment.FEATURE_STATS)}
    audit = {
        "status": "audited_post_training_metadata_failure",
        "experiment": "SW0109", "seed": 0, "unique_image_count": size,
        "registered_task_id": task["task_id"], "attempt_return_code": attempt["return_code"],
        "preflight_original_runner_sha256": old_runner_sha,
        "current_metadata_only_runner_sha256": sha(HERE / "run.py"),
        "state_sha256": state_sha, "preflight_sha256": pf_sha,
        "launch_evidence_sha256": sha(launch_path), "attempt_log": log_check,
        "recovery_helper_sha256": sha(Path(__file__)),
        "history_updates": len(history), "history_finite_and_objective_consistent": True,
        "prefix_checkpoint_update": 256, "prefix_parameter_change_count": len(prefix_changed),
        "full_checkpoint_parameter_change_count": len(changed),
        "graph_bitwise_unchanged_full_and_prefix": True,
        "preflight_pool_checks": preflight_checks,
        "pool_unique_count": len(pool), "pool_unique_sha256": pool_sha,
        "original_dataset_cli_argument": original_dataset_arg,
        "registered_cached_gamma_dataset": registered_dataset_path,
        "training_used_cached_gamma_not_hdf5_cli_argument": True,
        "training_exposures": len(order), "training_order_sha256": order_sha,
        "prefix_unique_images": counts[str(experiment.BATCH * 256)],
        "full_unique_images_seen": counts[str(experiment.EXPOSURES)],
        "periodic_progress_last_update": 4352,
        "original_started_utc": None, "original_completed_utc": None,
        "recovery_audit_utc": now, "input_sha256": input_hashes,
        "training_or_forward_pass_performed_by_recovery": False,
    }
    manifest = {
        "status": "training_complete", "seed": 0, "unique_image_count": size,
        "pool_unique_sha256": pool_sha, "training_order_sha256": order_sha,
        "training_image_ids_sha256": order_sha, "exposures": experiment.EXPOSURES,
        "updates": experiment.UPDATES, "batch_size": experiment.BATCH,
        "train_steps": 64, "settle": 32, "prefix_checkpoint_update": 256,
        "prefix_unique_images": counts[str(experiment.BATCH * 256)],
        "full_unique_images_seen": counts[str(experiment.EXPOSURES)],
        "pool_cycles": experiment.EXPOSURES // size,
        "pool_segment_contract": [[0, 999], [1640, 70639]],
        "remaining_pool_selection_seed": 108, "training_order_seed": 117,
        "learning_rate": 3e-5, "gradient_clip": 1.0,
        "optimizer": "fresh Adam per condition",
        "cycle_shuffle": "independent without-replacement permutation of the selected pool for each complete cycle",
        "objective": "phase primary + 5x positive-product actual-spike affinity",
        "graph_frozen": True, "encoder_frozen": True,
        "source_core_path": str(source_path), "source_core_sha256": source_sha,
        "source_manifest_sha256": sha(source_manifest_path),
        "train_gamma_sha256": gamma_sha, "train_gamma_manifest_sha256": gamma_manifest_sha,
        "encoder_sha256": experiment.sha(experiment.ENCODER),
        "feature_preprocessing_sha256": experiment.sha(experiment.FEATURE_STATS),
        "ground_truth_used_for_training": False, "best_epoch_selection": False,
        "started": None, "completed": None,
        "core_sha256": sha(out / "core.pt"),
        "runner_sha256": old_runner_sha,
        "recovered_manifest": True,
        "recovery_audit_sha256": None,
    }
    return audit, manifest


def atomic_json(path: Path, value):
    path = Path(path)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    if temp.exists():
        raise FileExistsError(f"preserve existing recovery temporary file {temp}")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temp, path)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, choices=experiment.SIZES, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--archived-master-state", type=Path, required=True)
    parser.add_argument("--archived-preflight", type=Path, required=True)
    parser.add_argument("--original-runner-backup", type=Path, required=True)
    parser.add_argument("--launch-evidence", type=Path, required=True)
    parser.add_argument("--error-log", type=Path, required=True)
    parser.add_argument("--write", action="store_true", help="write only after the full audit passes")
    args = parser.parse_args(argv)
    out = args.output_dir
    audit, manifest = audit_and_manifest(args)
    audit_path = out / "recovery_audit.json"
    manifest_path = out / "manifest.json"
    marker_path = out / "TRAINING_COMPLETED"
    result = {"status": "dry_run_passed", "task": f"train_seed0_N{args.size}",
              "audit": audit, "manifest": manifest}
    if args.write:
        for path in (audit_path, manifest_path, marker_path):
            if path.exists():
                raise FileExistsError(f"refusing to overwrite {path}")
        for path, expected in audit["input_sha256"].items():
            if sha(Path(path)) != expected:
                raise RuntimeError(f"scientific input changed before metadata recovery: {path}")
        atomic_json(audit_path, audit)
        manifest["recovery_audit_sha256"] = sha(audit_path)
        atomic_json(manifest_path, manifest)
        for path, expected in audit["input_sha256"].items():
            if sha(Path(path)) != expected:
                raise RuntimeError(f"scientific input changed during metadata recovery: {path}")
        marker_tmp = marker_path.with_name(marker_path.name + f".{os.getpid()}.tmp")
        if marker_tmp.exists():
            raise FileExistsError(f"preserve existing recovery marker temporary file {marker_tmp}")
        marker_tmp.write_text("SW0109 audited completed training; metadata recovered\n", encoding="utf-8")
        os.replace(marker_tmp, marker_path)
        result["status"] = "recovered_manifest_written"
        result["manifest_sha256"] = sha(manifest_path)
        result["marker_sha256"] = sha(marker_path)
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
