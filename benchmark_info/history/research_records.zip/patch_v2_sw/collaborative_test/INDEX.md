## SW0236: matched-budget data scaling continuation

Local18/Linux18 tests and3 CLI checks passed; actual three-seed CPU admissions started. Restore actual SW0226 TRAIN512/128 model+Adam+RNG, add384 updates, compare with SW0232 TRAIN64 at512 updates. GPU training waits for all SW0235 first attempts. No new result or fresh70000 training; full320 best remains SW0227.

[SW0236 start](SW_0236_native64_TRAIN512_exact_resume/START_KO.md)

## SW0235: fixed232 secondary64 validation started

Local8/Linux8 tests and2 CLI checks passed; actual three-checkpoint CPU admissions started before exclusive GPU queues. No new training: reuse16 masks and infer48 more per seed, comparing baseline and actual128 control. Preserve SW0232 original16 gate=false. Full320 best remains SW0227 .858916.

[SW0235 start](SW_0235_native64_convergence_validation64/START_KO.md)

## SW0232: exact continuation mini complete

Actual512 cumulative updates versus128: fixed16 three-seed .884622/.677086/.712312 vs .859634/.645611/.706340. FG delta +.024988, CI[-.006611,.062020]; original FG/balanced gates remain false. Three actual accepted128 prefixes and final512 checkpoints/144 raw masks independently audited. Promising mean increase needs matched secondary64 confirmation; full320 best remains SW0227 .858916.

[SW0232 result](SW_0232_native64_exact_teacher_resume/RESULT_KO.md)

## SW0234: peer-informed GT-assisted diagnosis, not model performance

Peer latest087cd82 reviewed. On our accepted native64 full320 masks: actualFG .858916, prescribed oracle merge .885762, coverage .883696, both .911458. Merge alone reduces Object IoU. Existing failed learned-merger/foreground branches remain closed pending a different justified approach. Actual best stays SW0227; SW0232 is running.

[SW0234 diagnostic](SW_0234_native64_oracle_error_decomposition/RESULT_KO.md)

## SW0227 full320: new verified FG reference

Three-seed means: .858916 / .605286 / .674313; comparable Slot: .786902 / .198201 / .195203. FG improvement over SW0210 +.010301, paired image CI [.005659,.014751]. Object IoU gain CI includes zero. Independent2880-mask audit passed; FG090 is not achieved. Supervised lineage; not fresh70000 training. SW0232 continuation pilot remains active.

[SW0227 result](SW_0227_native64_joint_projection_full320/RESULT_KO.md)

## SW0233: frozen frequency decomposition

CPU-only accepted-cache diagnosis: static omega within-class variance is much smaller than sensory variance in this fixed16 cohort. No causal attribution or model-score improvement claimed. Keep omega intervention low priority pending SW0232.

[SW0233 result](SW_0233_native64_static_frequency_diagnosis/RESULT_KO.md)

## SW0232: resume actual accepted128 checkpoint

SW0231 recomputation failed strict bitwise prefix checks; failed states are preserved. SW0232 restores actual SW0223 model/Adam/RNG and adds384 updates to cumulative512 on TRAIN64. Local16 and Linux16 tests plus3 CLI checks passed. Actual three-seed CPU admission precedes queues. No performance result yet; SW0227 full320 remains running.

[SW0231 failure](SW_0231_native64_teacher_convergence/RESULT_KO.md) | [SW0232 start](SW_0232_native64_exact_teacher_resume/START_KO.md)

## SW0231: original teacher loss convergence check

Same TRAIN64/source/objective/order/LRs; fixed512 updates vs accepted SW0223 at128. Actual128 model/Adam/history/Torch RNG prefix must match before update129. Local13 and Linux13 tests plus3 CLI checks passed; actual three-seed CPU admissions started. No performance result yet; SW0227 full320 confirmation continues.

[SW0231 start](SW_0231_native64_teacher_convergence/START_KO.md)

## SW0230 COMPLETE: source-relative separation did not improve FG

Fixed16/three-seed .852402/.624603/.711310 vs matched SW0223 .859634/.645611/.706340. FG difference -.007232, paired95% CI[-.014287,-.001225]. Both candidate gates failed. All144 masks/checkpoints/teachers independently audited. No full320/70k expansion. Keep SW0223/SW0225; SW0227 full320 confirmation continues.

[SW0230 result](SW_0230_native64_relative_separation/RESULT_KO.md)

## SW0230: source-relative separation preflight

Matched TRAIN64/128-update encoder+projection pilot; original center1 loss plus a natural source-distance contraction penalty. Local15 and Linux15 tests plus3 CLI checks passed; actual three-seed CPU admissions started before any GPU queue. No score yet; SW0227 full320 confirmation continues.

[SW0230 start](SW_0230_native64_relative_separation/START_KO.md)

## SW0228 COMPLETE: stronger source-center anchoring rejected

Fixed16/three-seed center16 .844707/.603466/.712916 vs center1 .859634/.645611/.706340. FG/balanced gates failed; no full320 or70k expansion. All144 masks and actual 128-update checkpoints/teachers independently audited. Full320 incumbent unchanged; SW0227 confirmation continues.

[SW0228 result](SW_0228_native64_center_preservation/RESULT_KO.md)

## SW0229 COMPLETE: CPU-only accepted-mask error diagnosis

Same64/three-seed accepted SW0225 masks: per-image split rate8.32%->6.10%, merge4.27%->4.62%; these rates have different denominators. Foreground precision62.6%, recall94.8%. Only3/51194 GT foreground patches lie outside their largest visible component. No new model result, GPU forward or learning. SW0227 continues and SW0228 remains queued. Full320 incumbent unchanged.

[SW0229 diagnosis](SW_0229_native64_partition_diagnosis/RESULT_KO.md)

## SW0228: source-center preservation comparison admitted/deferred

Natural source-center loss weight1->16; same TRAIN64/128updates and actual encoder/core projection. All3 actual CPU admissions,14 Linux tests and3 CLI checks passed. Three live supervisors wait until all SW0227 seeds have received their first GPU allocation. No GPU training or performance result yet; SW0227 continues and full320 incumbent is unchanged.

[SW0228 queued test](SW_0228_native64_center_preservation/START_KO.md)

## SW0226 COMPLETE: small matched-budget data-size change, scaling unproven

Fixed16/three-seed TRAIN512 .860512/.650250/.712453 vs matched TRAIN64 .859634/.645611/.706340. All paired data-size CIs include zero. All144 masks and actual128-update encoder/projection checkpoints independently audited. Source-relative candidate gate passed; data-scaling gate failed. No70k expansion. SW0227 full320 confirmation of SW0223/SW0225 continues; incumbent unchanged.

[SW0226 result](SW_0226_native64_joint_projection_TRAIN512/RESULT_KO.md)

## SW0227: full320 confirmation queued/running, no new training

All3 actual fixed checkpoint/CPU admissions, actual Slot controls, 9 Linux tests and 3 CLI checks passed. Reuses64 images and predicts256 more per seed, plus exact replay. Fixed models are SW0223, selected by SW0225. No new performance result; SW0210 full320 incumbent unchanged. SW0226 continues.

[SW0227 start](SW_0227_native64_joint_projection_full320/START_KO.md)

## SW0225 COMPLETE: secondary64 candidate passed

Fixed SW0223 three-seed mean .877164/.597239/.670309 versus matched source .864270/.571015/.669769. FG and FIoU paired CIs are positive; Object IoU CI includes zero. All384 masks independently audited. Full320 confirmation selected, not completed. Original16 gate failure and SW0210 full320 incumbent remain unchanged. SW0226 continues.

[SW_0225_native64_joint_projection_validation64](SW_0225_native64_joint_projection_validation64/RESULT_KO.md)

## SW0226: joint projection TRAIN512, same128updates

All3 actual CPU admissions passed; three exclusive-GPU queues registered. Matched TRAIN64 control is SW0223; no new performance score. SW0225 continues; full320 incumbent remains SW0210.

[SW0226 start](SW_0226_native64_joint_projection_TRAIN512/START_KO.md)

2026-10-18 SW0225 ACTUAL GPU START: fixed223 checkpoints, secondary first64 validation IDs1320..1383. No new training/hyperparameter selection. Original16 masks reused after exact RGB/hash checks and one native replay/seed;48 new predictions/seed. 7 local/7 Linux tests,3 actual model/RGB64 CPU admissions and actual GPU mask replay passed. Original22316 gate failure and full320 .848615/.592533/.672047 incumbent remain unchanged.

2026-10-18 SW0223/224 COMPLETE:223 joint32-weight projection fixed16 mean .859634/.645611/.706340 vs source .842891/.600692/.702161 and222 .854272/.631545/.695736. Source FG CI[-.000361,.040940] includes0; original gate False.144 masks/checkpoints/control audited; separate fixed223 validation64 is225. 224 feature-cell alignment mean .838302/.586019/.713245, gate False; retain uncertain Object IoU track, no FG expansion.96 masks/source/adapter audited. No audit retraining/forward. Full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0224 ACTUAL GPU START: independent zero-update feature-cell alignment. Existing126 feature maps gain one replicated feature border before64 pooling; interior cells align with unchanged2px modal GT. Source CNN/core/statistics/RGB/GT/readout fixed; adapter code SHA distinguishes the model variant. 7 local/7 Linux tests,3 actual source/checkpoint/geometry CPU admissions and three exclusive idle GPU queues. 223 joint-projection tests continue. No new score; full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0223 ACTUAL GPU START: joint encoder+actual32-weight gamma-to-drive projection, same source teacher/gamma anchor/TRAIN64/128 updates as222. All remaining core state frozen; original spike readout. Matched source and222 encoder-only controls frozen before GPU. 9 local/9 Linux tests including exact encoder/projection/Adam interrupted resume and full scoring;3 actual positive projection-gradient CPU admissions. Three exclusive idle GPU queues. No new score; full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0222 COMPLETE: fixed16 three-seed .854272/.631545/.695736 vs source .842891/.600692/.702161. FG+.011381 CI[-.004210,.034446], Object IoU down; full320 expansion gate False. Retain uncertain FG-track model; no70k expansion. DEV within-object frequency variance decreases all3 seeds; actual3 encoder checkpoints/teacher and96 masks independently audited. No repeated full-model factory or extra forward in audit. Full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0222 ACTUAL GPU START: source object-frequency teacher denoising plus original gamma anchor, without unit-distance repulsion. TRAIN64 x seeds0/1/2,128 encoder updates/B16, original core/gates/readout unchanged. 9 local/9 Linux tests including exact interrupted resume;3 actual teacher CPU admissions passed with natural source variance/zero gamma anchor. Three exclusive idle GPU queues. No new score; full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0221 COMPLETE: fixed16 three-seed baseline .842891/.600692/.702161; TRAIN64 .705741/.243287/.581092; TRAIN512 .693004/.239999/.574074. Both expansion gates fail; all seed metrics decline. TRAIN and DEV within-object frequency variance increased despite lower total loss. Unit-margin branch closed; no epoch/LR/margin sweep or70k expansion. Actual six encoder checkpoints and all means/bootstrap CIs audited; no extra core forward in diagnosis. Full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0221 ACTUAL GPU START: supervised whole-encoder effective-frequency pretraining, actual omega+gain*drive compactness/adjacent-class separation. Core/gates/readout unchanged. TRAIN64 vs512 x seeds0/1/2, same128 encoder updates/B16, six exclusive idle GPU queues. 12 local/12 Linux tests and six actual CPU admissions passed. All six endpoints freeze before GT. Not new70k training or core joint training; no new score. Full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0220 COMPLETE: same-gradient TRAIN4 actual loss2.819465 -> 2.951871 inherited Adam /2.919585 reset Adam; both uphill, no reset-training followup. Actual source model/Adam/RNG restored, parent checkpoint unchanged; 16 native image forwards,2 temporary steps,0 committed updates. Report arithmetic/source content audited. Optimizer-state branch closed; full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0220 ACTUAL GPU START: same-gradient native64 TRAIN4 Adam-state keep/reset diagnosis after218 uphill proposal. Two temporary steps then exact model/Adam/RNG restoration; zero committed updates. 8 local/8 Linux tests,2+2 CLI checks and actual CPU admission passed; worker2397214 on exclusive GPU1. Peer7a21632 rechecked. No segmentation result; full320 .848615/.592533/.672047 unchanged.

2026-10-18 SW0218 COMPLETE after CPU-only score recovery: fixed16 seed0 .898687/.858750/.729999 vs204 FG .900539 and warm .924401; no FG gain. Actual two updates, changed CNN/model and auxiliary S/all-five-family parameter credit verified; model/Adam/RNG and48 mask endpoints audited. Renamed control import fixed in separate scoring module; zero retraining. SW0219 also complete: Q-only mean FG .833809 vs .842891; retain A weighting. Full320 .848615/.592533/.672047 incumbent unchanged; goal remains active.

2026-10-18 SW0219 COMPLETE: native64 fixed16 three-seed Q-only readout FG 0.833809 vs baseline 0.842891; delta -0.009081 CI[-0.022494,-0.000757], expansion gate False. All48 actual Q/A replays and96 mask endpoints audited; zero GPU/core forward/update. Physical graph dynamics remain intact. SW0218 scoring recovered and independently audited. Full320 .848615/.592533/.672047 incumbent unchanged.

2026-10-18 SW0219 ACTUAL CPU START: all-three-seed native64 fixed16 Q-only readout comparison on cached actual217 Q/A, original graph dynamics and foreground retained; zero GPU/core forward/update. Local4/Linux4 tests plus actual48-row cache/native64 readout admission passed. Worker2370169. All96 endpoints will be frozen before GT scoring. SW0218 training remains active; full320 incumbent .848615/.592533/.672047 unchanged.

2026-10-18 SW0218 ACTUAL GPU START: energy-ranking auxiliary on native64 with unchanged production readout, exact SW0204 warm192 model/Adam/RNG and two new B4 proposals. 22 local/22 Linux tests and actual CPU admission passed; worker2368524 on exclusive GPU1. No gain claimed. Peer7a21632 withdraws short-budget native32 three-seed claim; reviewed without importing unmatched scores. Full320 .848615/.592533/.672047 unchanged.

2026-10-18 SW0217 COMPLETE: fixed16/native64 three-seed baseline FG .842891 unchanged by energy split/refinement; ObjectIoU +.00001847 only. All48 actual Q/A rows and144 masks independently replayed/audited. Posthoc actual-Q pair AUC .9778/.9237/.9366, but false-merge positive-energy fractions .9958/.9818/.8959. Stop same-energy optimizer sweeps; diagnose TRAIN-only evidence/decision alignment, not DEV threshold tuning. Full320 incumbent .848615/.592533/.672047 unchanged; .90 remains unmet.

2026-10-18 SW0217 ACTUAL START: native64 fixed16 seeds0/1/2 signed-energy split/refinement, exact best-reference baselines and original foreground; zero updates. 8 local/8 Linux tests plus actual CPU source/disk admissions passed. Seeds0/1 on exclusive GPUs1/3, seed2 queued. No result yet. Full320 incumbent .848615/.592533/.672047 remains unchanged.

2026-10-18 SW0216 COMPLETE: foreground-conditional TRAIN relation target at identical features/weights/init yields .781651/.445474/.665117 vs original .788414/.445474/.674335; no gain, matched215 FG unchanged. 17 local/17 Linux tests and actual CUDA Adam128/64 endpoints audited. GT-assisted merge examples FG .847321/.849997 are not predictions or certified bounds. Close small target/threshold sweeps; examine native-energy splitting, since current groups are already4-connected. Full320 three-seed .848615/.592533/.672047 remains.

2026-10-18 SW0214/SW0215 COMPLETE: source-component merger raw primary FG .720607 vs original .788414; frozen geometry .814008 has FG CI crossing0 and lower ObjectIoU. TRAIN-only weighted-BCE odds correction3.263823 restores primary to .781651, no gain; corrected geometry equals baseline. 8+8 and4+4 tests passed, actual128 Adam / 48 and80 endpoints audited. Full320 three-seed reference remains .848615/.592533/.672047. Next inspect foreground-conditional relation targets with unchanged evaluation.

2026-10-18 SW0211/SW0212/SW0213 COMPLETE: center128 FG .034678, learned-FG128 .000000, center512 .589666 versus original .788414 on fixed16 seed2/native64. Actual128->512 Adam continuation resolved TRAIN center detection (98.77 percent recall), not validation grouping. No further center-budget sweep. Preserve count pilot4/16 exact without a stability claim. Full320 three-seed incumbent remains .848615/.592533/.672047. Next: preserve core components and learn same-object merger corrections. Goal remains active for .90.

2026-10-18 SW0210 posthoc full320 support diagnosis: actual masks unchanged, zero forward/update. GT foreground misses6.37/8.12/3.70 percent for seeds0/1/2; covered split2.97/9.05/6.29 percent. Full FG weakest seed1; mini weakest seed2 is not a population ranking. Continue211 grouping and212 learned-foreground comparison; actual mean .848615 unchanged. GT-assisted references are not model performance. See SW_0210_native64_full_seed_reference/SUPPORT_DIAGNOSIS_KO.md.

2026-10-18 SW0210 COMPLETE: fixed320/native64 independent seeds0/1/2 mean .8486147855/.5925328333/.6720472673 versus Slot .7869016920/.1982007892/.1952025237; all3 strict means pass. All1920 masks/dual metrics/paired image CIs independently recomputed. Mask-supervised adapted lineage; zero new training in210; no fresh70k. FG>=.90 remains unachieved; goal stays active with211 GPU3 and212 dependency queue. See SW_0210_native64_full_seed_reference/RESULT_KO.md.

2026-10-18 SW0211 ACTUAL GPU START: worker2337998/start448637534 on GPU3 after SW0210 seed2 completed all4 prediction shards. Frozen-core descriptor extraction, then TRAIN32 center head fit; no head-training completion or gain claimed. Actual NVIDIA/process evidence: SW_0211_spike_anchor_center_assignment/results_archive/started_v1/actual_GPU_start.json. SW0210 seed1 full evaluation remains active; SW0212 waits for211.

2026-10-18 SW0212: prospective frozen-head learned-foreground readout queued after SW0211; CPU only, zero new optimizer steps; five local/five Linux tests and native64 CPU admission passed. Supervisor2285616/start448185348. Registered before211 score existed; exact parent-mask replay required before GT scoring. See SW_0212_learned_foreground_center_readout/README.md. No improvement claimed.

Queued2026-10-18: [SW0211 spike-anchor center assignment](SW_0211_spike_anchor_center_assignment/DESIGN_KO.md),
actual source seed2, TRAIN32, frozen core and exactly preserved foreground.
17 local+Linux tests and real native64 CPU admission passed. No new score yet.

Completed2026-10-18: [SW0209 pair-ARI+QCE](SW_0209_native64_foreground_pair_ari/RESULT_KO.md)
fixed16 seed0 .901220/.862279/.736022; FG+.001072 versus matched control,
CI includes0, no expansion. [SW0210 full320 seed reference](SW_0210_native64_full_seed_reference/DESIGN_KO.md)
continues. [Posthoc fixed-support attribution](SW_0208_native64_full320_confirmation/SUPPORT_DIAGNOSIS_KO.md)
supports testing instance grouping; GT references are not new model scores.

Latest2026-10-18: [SW0207 completed diagnosis](SW_0207_spike_foreground_classifier/README.md);
[SW0208 full320 confirmation complete](SW_0208_native64_full320_confirmation/RESULT_KO.md).
These supersede historical running observations below. SW0208 compares actual204
and stronger warm192, native64 seed0, before considering70k expansion. No new
full320 .90 or three-seed native64 result yet. Seed0 warm192
.877709/.791224/.696284;204 .876242/.790093/.693262. Warm retained as reference.

Current results are summarized in [STATUS.md](STATUS.md). [SW0148 live queue v3](SW_0148_checkpointable_boundary_q/results_archive/server_start_v3_20261012/summary.json): supervisor551842 launched; 11 Linux CPU tests passed; idle admission shortened to5 seconds after an observed short GPU2 opportunity. Owner guards, launch recheck, strict checkpoint GPU binding and scientific recipe are unchanged. Both training arms were waiting at launch. No new segmentation score is claimed.

Latest recovery observation: three actual training children verified in /proc and nvidia-smi on GPUs0/1/2. No scores yet. Evidence: SW_0134_native_spike_binding/recovery_gpu_start_20261010.json.

SW0134 technical GPU-owner interruption archived; unchanged-code queue2566458 verified alive waiting for exclusive GPUs. No saved checkpoint or new score. Evidence: SW_0134_native_spike_binding/owner_interruption_recovery_20261009.json.

SW0134 paired seed1 pilot launched: actual_joint, gate_joint and actual_frozen children verified live on GPUs3/2/1. Initial import failure occurred before updates and was preserved; module-entrypoint repair passed seven server CPU checks. No scores, promotion, all-gating proof or scaling proof. Evidence: SW_0134_native_spike_binding/pilot_launch_review_20261009.json.

SW0133 completed: three-arm seed1 attribution positive versus controls, source superiority unproved; registered expansion failed,97 unchanged. [Terminal evidence](SW_0133_soft_partition_rgb/results_archive/terminal_pilot_20261009/summary.json). SW0134 prospective: [native-spike learned binding](SW_0134_native_spike_binding/README.md),10CPU helper tests passed; no server134 training or scores.

SW0133: [soft-partition joint-learning pilot](SW_0133_soft_partition_rgb/README.md) - three source preflights passed; actual seed1 phase_live GPU training started; all3 arms train/eval queued, no scores yet. [Launch evidence](SW_0133_soft_partition_rgb/pilot_launch_review_20261009.json).

# Collaborative experiments

| ID | Status | Change | Validation result |
|---|---|---|---|
| SW0142 | planned; local CPU verified; awaiting SSH | Masked native32 RGB completion, paired encoder+graph-only versus core-trainable arms | 14 tests discovered: 13 pass and one Windows-only flock test skip; no server/GPU run. [Review](SW_0142_native32_masked_completion/results_archive/local_cpu_review.json). |
| SW0132 | closed at seed0 scientific preflight failure; no training | Relative-coordinate RGB decoder driven by the registered hard-H spike partition; phase and constant-state arms | Server/local CPU tests 10/10 and all three source contracts passed. Hard-H row shuffling had mean RGB-loss excess -9.81e-5 in both arms (20/64 positive images); source parity/credit checks passed. Decoder warmup and disposable steps ran, but joint training remained at0 updates; seeds1/2 were blocked. No retry, score, or incumbent change. |
| SW0137 | complete; native32 fixed-source baseline | Source97 native32 actual-spike QCC on the fixed320 endpoint, compared with fixed Slot32 | Means FG-ARI/foreground-IoU/object-IoU .781919/.605427/.597014 vs Slot .781652/.204360/.203165. FG advantage is tiny and its paired interval includes zero; no fresh native32 training or scaling claim. [Analysis](SW_0137_native32_source_qcc/results_archive/source32_analysis.json). |
| SW0138 | complete; score-only event-information comparison | Same frozen native32 source, actual-spike readout vs retained-gate readout | Source exactly reproduces SW0137; gate-readout FG difference is effectively zero with CI crossing zero. No gate-removal/necessity or scaling claim. [Analysis](SW_0138_native32_event_information/results_archive/event32_analysis.json). |
| SW0139 | completed seed1 pilot; expansion closed | Native32 representation arms: control, context residual, cross-view; source97 reference | FG-ARI means .754135/.726187/.666608/.738505 (source/control/context/cross-view). Both expansion gates failed; no three-seed promotion. [Final analysis](SW_0139_native32_representation/results_archive/final_evaluation_analysis.json). |
| SW0140 | complete; fixed320 causal screen | Six frozen-source dynamics/readout interventions across three seeds | Kuramoto-off and gate=.5 sharply reduce scores; dendritic-history removal has a smaller decline; membrane-history, reset-off, and forced-on events show no material FG gain. No training or claim that every gate is necessary. [Results](SW_0140_native32_causal_screen/README.md). |
| SW0141 | completed seed1; score recovered; expansion closed | C-only vs C+source-Q on native32 encoder+graph | FG .752123/.752108 vs source .754135 and Slot1 .841819; no promotion or70k expansion. [Result](SW_0141_native32_source_preservation/README.md). |
| SW0126 | all3 feasibility PASS; paired seed1 training live | History-centered membrane events and imagewise full-trace binder; matched actual-spike versus continuous-gate pilot | Server29 CPU checks and real3source CPU attachment PASS; all3 TRAIN64 feasibility screens PASS with event occupancy .387-.528 and reconstruction gradients. Both disposable optimizer preflights PASS; matched4096 two-arm training live, no scores yet. |
| SW0109 | queued; upstream dependency waiting | Matched2500/10000/70000 nested unique-image pools from audited pre-large-data cores; equal70k additional exposures, three seeds, dependency-aware exclusive GPU concurrency | Frontier13 CPU tests pass. Coordinator verified live, all24 tasks queued, no GPU worker yet. See [README](SW_0109_unique_data_scaling/README.md). |
| SW0108 | queued; GPU waiting | Frozen SW0097 seed0 baseline followed by five one-at-a-time physical rollout interventions; exact full320 baseline reproduction required | First attempt invalid due missing explicit .06 membrane threshold and safely archived. Corrected Frontier6 CPU tests pass; coordinator verified live, no GPU worker yet. See [README](SW_0108_gate_contribution_screen/README.md). |
| SW0107 | complete; official-data transfer loses FG-ARI | Additional official-CLEVR70k continuation of each frozen best SW0097 core, then our native320 evaluation | Three-seed mean .769423/.532391/.591882; lower FG-ARI than matched native-trained Slot .774933. Additional continuation, not a data-only from-scratch comparison. See [README](SW_0107_official_full70k_transfer/README.md). |
| SW0106 | seed0 pilot complete; registered expansion rejected | Matched reconstruction credit through actual-spike partition versus detached-assignment control | Candidate .832810/.723735/.667637; control .815322/.719565/.648090. Candidate misses preregistered +.01 FG margin against SW0097 seed0, so no seed1/2 or full70k expansion. |
| SW0102 | complete; cannot-link recipe stopped | Add a calibrated maximin-bottleneck cannot-link term to the matched frozen-graph continuation; no GT in training | All three matched 256-update candidates and full320 evaluations completed. Mean `.773720/.577959/.600421` vs SW0097 `.776348/.577070/.601537`; FG-ARI fell all3, so registered promotion fails and no 70k run. Cut loss/conflict trends and provenance are archived. See [README](SW_0102_cannot_link_draft/README.md) and [summary](SW_0102_cannot_link_draft/results_archive/summary.json). |
| SW0103 | complete; one-pass triangle readout rejected at fixed16 gate | On frozen SW0097 cores, drop q≥.50 synchrony edges without common neighbors; restore only raw size-2 components | Raw classifier reproduced archived metrics exactly. Triangle mean deltas on IDs1320-1335 were `-.000969/-.000425/+.002844`; only 1/3 seeds gained FG-ARI, so no full320 follow-up. Cross-instance coassignment fell and same-instance recall stayed within the fixed tolerance. See [README](SW_0103_triangle_readout/README.md) and [results](SW_0103_triangle_readout/results_archive/first16.json). |
| SW0100 | complete; foreground-IoU tradeoff, no expansion | Opt-in phasor-imaginary raw gate on matched SW0095 seeds; legacy raw/default preserved | All three candidates completed 256 updates and valid full320. Mean `.763415/.706827/.590691`; vs matched SW0097, FG-ARI falls all3, foreground IoU gains all3, object IoU gains 1/3. Corrected fixed16 source/candidate swaps archived; the exact user-priority FG-ARI promotion gate fails, so no70k run. See [README](SW_0100_phasor_imag_raw_gate/README.md) and [summary](SW_0100_phasor_imag_raw_gate/results_archive/summary.json). |
| SW0101 | complete; teacher-mask recipe rejected at Stage 1 | Freeze graph/cosine-derived near/mid positive and negative masks on validation IDs1320-1335, then score once against GT | Positive precision `.9130/.6757` misses `.95` in both bins; mid coverage is 10/16 (<12). No threshold tuning, loss implementation, or training. See [README](SW_0101_teacher_mask_qa/README.md) and [results](SW_0101_teacher_mask_qa/qa_results.json). |
| SW0099 | complete; validation-only stage-flow diagnosis | Trace graph-to-phase-to-gated-carrier-to-dendrite-to-membrane-to-spike on 16 validation IDs, batch 8, across SW0095/97/98 matched seeds | Corrected traces show graph states exactly equal; earliest distance-controlled AUC decline is at the delayed raw gate and persists at spike. Endpoint means are diagnostic, not full-320 results; no causal claim. See [README](SW_0099_stage_flow_diagnosis/README.md) and [summary](SW_0099_stage_flow_diagnosis/summary.json). |
| SW0098 | complete; longer training window rejected on grouping metrics | Matched SW0097 frozen controls; 256/128 training, same source/IDs/shuffle/256 updates; only window changed | Mean .773412/.579282/.597119 vs matched frozen .776348/.577070/.601537. FG-ARI/object IoU lower; foreground IoU higher. FG-ARI drops all3 seeds. Does not beat Slot mean on FG-ARI; holdouts untouched. See SW_0098_long_window. |
| SW0097 | complete; graph adaptation loses all3 means | From each whole SW0095 core, compare graph frozen/trainable under identical aligned-loss256-update continuation | Frozen .776348/.577070/.601537 vs graph .769307/.575107/.596571. Graph FG-ARI lower in all3 seeds; do not expand this recipe to70k. All six raw results archived. |
| SW0096 | complete; FG-ARI advantage did not generalize | Freeze SW0095 and Slot epoch10 cores on independent and previously inspected reference splits | Independent means ours .759817/.562696/.588620 vs Slot .777602/.196114/.201021. Two IoUs win; FG-ARI loses. All12 evaluations archived; reserve90640??0959 unread. |
| SW0095 | complete; narrow numerical validation exceedance | Aligned-loss whole-core continuation for source seeds0/1/2, one complete additional70k pass each | Mean .775645/.574029/.599779 vs Slot .774933/.203589/.206937; margin .000711 FG-ARI. No final superiority claim: SW0096 holdout fails FG-ARI. Total downstream two70k passes vs Slot ten. |
| SW0094 | complete; all four arms | Continue whole70k core for256 updates; align spike loss, then train graph and encoder | Frozen aligned pilot .847604/.729511/.676380. Full320 joint .809536/.722944/.652387 vs aligned-frozen .822115/.718331/.661153; retain IoU tradeoff. One source seed and4,096 additional images. |
| SW0093 | analysis complete; causal tests proposed | Diagnose 70k scaling failure from completed checkpoints' scores, archived training logs and active loss/classifier code | Training uses absolute correlation; classifier uses positive correlation. All3 seeds reduce endpoint loss but lose FG-ARI; count MAE 1.776 -> 3.279. No new GPU training; see SW_0093_scaling_failure_analysis/README.md. |
| SW_0034 | planned, execution pending SSH | Stage-wise object-signal AUC at fixed pair distances and training-loss gradient connectivity; unchanged core observed with hooks | No results yet; syntax check passed; spatial-only and membrane/spike spatial controls prepared |
| SW_0035 | complete, classifier reference suite | GT-free adaptive spectral object-count baseline on actual membrane/gated-spike patterns, compared with adaptive slots and fixed-k controls | Full320 eigengap .490649/.204761/.140716, count MAE 1.925; improves fixed spike ARI/FG IoU/count but lowers object IoU; weakly adaptive |
| SW_0036 | complete, spike all-metric calibration gain | Frozen checkpoint threshold sweep after binary event saturation diagnosis | Full320 vth2 spike spatial k10 .487351/.192635/.172932 vs vth.06 .479762/.185651/.164179; event rate 1.0??299, but object AUC remains weak |
| SW_0037 | complete, mixed | Matched 40-epoch seed-0 membrane-PLV training with vth 2.0 instead of .06 | Saturation repaired, but fixed membrane .478921/.200110/.174031 and spike .461878/.204486/.174888 trade lower FG-ARI for higher IoUs; no seed expansion |
| SW_0038 | complete stage comparison, classifier finalizing | Matched vth2 phase-only control versus additive product-combined component-spike PLV weights .25 and 5 | Full320 spike rows: control .407526/.228462/.194464, weight.25 .416059/.228732/.190776, weight5 .435727/.226240/.198260; dose response but no all-metric lead |
| SW_0001 | completed | Spike synchrony spectral readout, fixed k=8 | FG-ARI 0.136286; foreground IoU 0.271997; matched object IoU 0.145604 on CLEVR IDs 1320??639 |
| SW_0002 | complete, mixed result | Membrane-sourced synchrony objective, 10-epoch pilot | Spike FG-ARI 0.270323, foreground IoU 0.235452, object IoU 0.123274 on validation; not an all-metric gain |
| SW_0003 | complete, mixed result | Matched 40-epoch membrane-PLV follow-up to isolate source change | FG-ARI 0.2889, foreground IoU 0.2075, object IoU 0.1027; no all-metric gain |
| SW_0004 | complete, mixed result | Preserve phase PLV; add graph-to-membrane synchrony KL at weight 0.1, 10-epoch pilot | Spike FG-ARI 0.202940; foreground IoU 0.245920; matched object IoU 0.142077. Membrane gradients connected, but no all-metric gain |
| SW_0005 | complete, mixed result | Prediction-only perimeter rule for background clusters; no model retraining | Foreground IoU rose to 0.3220, but FG-ARI fell to 0.0495 and object IoU to 0.1386 |
| SW_0006 | complete, mixed result | Reproduce peer `patch_v2:5a29422` connected-components spike classifier on our fixed HDF5 split | At threshold 0.95 aggregate: FG-ARI 0.077165, foreground IoU 0.328720, matched object IoU 0.173560; better IoUs but worse ARI than SW_0001 |
| SW_0007 | complete, negative result | Peer connected-component foreground selection followed by spike-pattern spectral grouping of only foreground patches | Threshold 0.95, k=5: FG-ARI 0.080966; foreground IoU 0.328720; matched object IoU 0.134053. No all-metric gain |
| SW_0008 | complete, improvement candidate | Apply peer spike classifier to SW_0003 and SW_0004 trained cores on same validation split | SW_0004 + component-product threshold 0.50: FG-ARI 0.195269; foreground IoU 0.275711; matched object IoU 0.238803, all above SW_0001 seed-0 validation |
| SW_0009 | complete, goal unmet | Frozen SW_0008 readout on reference test IDs 1000??319 | FG-ARI 0.190909; foreground IoU 0.270928; matched object IoU 0.229805. Slot reference 0.890115 / 0.212251 / 0.235487 |
| SW_0010 | complete, negative result | Lower peer component-product spike edge threshold to reduce object fragmentation; validation only | At 0.10 groups fall 30.99??8.77, but FG-ARI 0.183586, foreground IoU 0.266737, object IoU 0.197857 all below threshold 0.50 |
| SW_0011 | complete, mixed result | Match the SW_0004 graph-teacher pilot to 40 training epochs, seed 0 | Best ARI 0.179760 / FG IoU 0.271468 / object IoU 0.295250 at component-product 0.50; predicted groups 77.03 vs true 6.20; no all-metric gain over SW_0008 |
| SW_0012 | complete, diagnostic only | Test peer `patch_v2:0dd2115` geodesic graph distance on our existing checkpoint, without modifying core | Same/different-object edge ratio 15.00??3.59 on 16 validation images; not merged |
| SW_0013 | complete, mixed result | User-proposed adaptive cosine slots on observed spike histories; no retraining | Best ARI 0.247376, FG IoU 0.248332, object IoU 0.204032; groups 17.37 vs true 6.20. ARI improves but both IoUs worsen; not adopted |
| SW_0014 | complete, negative result | Compare background inference rules for SW_0013 adaptive slots | Border rule lifts foreground IoU to 0.338240 but FG-ARI drops to 0.071979 and object IoU to 0.177311; not adopted |
| SW_0015 | complete, diagnostic | Verify cached gamma versus HDF5 image index alignment | Same-index RGB/gamma boundary fingerprint ranks top-1 for 27/128 train and 26/128 validation images, versus 1/128 random expectation; strongly supports alignment |
| SW_0016 | complete, mixed result | Add optional `patch_sw`-derived RGB-edge membrane separation loss to matched SW_0011 seed-0 training | At same component-product .50 readout: FG-ARI .069476 / FG IoU .331876 / object IoU .164980, versus SW_0011 .179760 / .271468 / .295250; no all-metric gain |
| SW_0017 | complete, mixed result | Run the same adaptive slots on continuous membrane instead of binary spikes | At threshold .7/six slots: FG-ARI .261507, FG IoU .246264, object IoU .207637, groups 18.18; only small gains over spike slots and worse IoUs than existing readout |
| SW_0018 | complete, mixed result | Peer-inspired low-spike-synchrony foreground ranking plus our adaptive slots | Best FG IoU .291989 comes with FG-ARI .130456 and object IoU .177966; no all-metric gain |
| SW_0019 | complete, mixed pilot | Mix actual spike and membrane per-component affinities at readout on SW_0011 checkpoint | On 64 validation images, 25% membrane improves FG-ARI .157762 to .188753 and FG IoU .257242 to .268401, but object IoU falls .296283 to .259725; not adopted |
| SW_0020 | complete, mixed result | Apply the existing graph-teacher loss to actual spikes rather than membrane; matched SW_0004 10-epoch settings | At component-product .50, FG-ARI .122560 / FG IoU .260356 / object IoU .287220 versus SW_0004 .195269 / .275711 / .238803; object IoU gains but priority FG-ARI falls |
| SW_0021 | complete, FG-ARI improvement | Apply user-proposed adaptive slots to SW_0003 high-ARI core, comparing actual spike versus membrane histories | Membrane slots: FG-ARI .357053 / FG IoU .209870 / object IoU .113992, mean predicted groups 5.98 vs true 6.20; retain ARI-first track and improve foreground next |
| SW_0022 | complete, small all-metric gain | Use a border membrane pattern as an additional per-patch background cue on SW_0021's fixed membrane slots | Largest-slot AND template similarity >=.90: FG-ARI .361770 / FG IoU .215081 / object IoU .119675; predicted FG .677 vs GT .217, so background remains a major IoU gap |
| SW_0023 | complete, diagnostic | Measure SNN activity features versus GT foreground and the oracle-foreground ceiling for frozen SW_0021 grouping | Single-feature AUC weak (best inverse border similarity .611); oracle foreground raises FG IoU to 1 and object IoU to .385 but **FG-ARI remains .357**, proving grouping is the ARI bottleneck |
| SW_0024 | complete, all-metric validation gain | Compare membrane spectral clustering with adaptive slots on the same high-ARI SW_0003 core | Absolute-correlation spectral k=10 scores FG-ARI .393974 / FG IoU .228821 / object IoU .150706 vs slots .357053 / .209870 / .113992; seed-0 validation only |
| SW_0025 | complete, tradeoff | Extend spectral cluster count beyond k=10 on the same SW_0003 core | Full validation: k=10 retains top FG-ARI .393974; k=20 raises object IoU .150706 to .228019 but lowers FG-ARI to .348207 and predicts 19 groups/image; preserve separate tracks |
| SW_0026 | complete, threshold tradeoff | Recheck peer-inspired very low spike-product thresholds on three frozen cores | SW_0004 .50 remains best of this sweep on all metrics; SW_0011 .10 lifts foreground IoU .271468 to .331330 but lowers FG-ARI .179760 to .098892 and object IoU .295250 to .180793. Keep as IoU track, not the ARI lead |
| SW_0027 | complete, IoU tradeoff | Compare component-wise membrane affinity with the existing aggregate spectral k=10 readout | On full 320 validation, aggregate remains FG-ARI leader .393974/.228821/.150706; component positive mean gives .386094/.232912/.157926. Retain both FG-ARI and IoU tracks |
| SW_0028 | complete, FG-ARI gain | Spatial Gaussian weight on existing membrane spectral affinity, same checkpoint | On full 320 validation sigma=1.5 raises FG-ARI .393974 to .494639 and object IoU .150706 to .170568, but foreground IoU falls .228821 to .191070. New ARI-first candidate; foreground selection remains a separate problem |
| SW_0029 | complete, no new FG-ARI lead | Refine spatial sigma .75-2 and spectral k6/8/10 on same frozen core | First-64 validation keeps sigma1.5/k10 best FG-ARI .530110; k6/8 lower ARI. Sigma1.25/k10 gives only a tiny object-IoU increase .176630 to .178952 with lower ARI .520789; not promoted to full320 |
| SW_0030 | complete, negative border pilot | Add whole-group background removal by border-patch fraction to SW_0028 readout | First-64 validation: foreground fraction .865 to .228 at border threshold .2, but FG-ARI .530 to .261; foreground IoU only .184 to .198. Correct foreground amount does not locate the right patches; no full320 promotion |
| SW_0031 | complete, foreground-IoU tradeoff | Intersect SW_0028 spatial group labels with independent nonspatial membrane foreground masks on same core | Full320: spatial FG-ARI .494639/FG IoU .191070/object IoU .170568; positive-mask hybrid .432699/.205366/.161077. IoU rises slightly but both grouping metrics fall; keep only as foreground-IoU candidate |
| SW_0032 | complete, two-IoU tradeoff | Apply SW_0031's independent membrane veto only within a selected border width | Full320 width2: FG-ARI .467718 vs control .494639, foreground IoU .210417 vs .191070, object IoU .174335 vs .170568; retain separate IoU track, spatial control remains ARI lead |
| SW_0033 | complete, critical diagnostic | Separate learned membrane affinity from spatial distance prior and random-permutation null | On full320, spatial-only FG-ARI .491272 versus actual membrane횞spatial .494639; learned increment tiny. Raw membrane same-vs-different-object nearby-pair AUC .6365 versus spatial-only .6979. Prioritize membrane-learning signal, not geometry tuning |

Each experiment's README begins with a Korean plain-language explanation and a
baseline-versus-candidate table when results exist. Arrows in those tables
mean higher is better; no score is combined into a single total. These are
validation scores from seed 0, not three-seed test results or a goal claim.
Continue promising single-metric results rather than requiring every
intermediate ablation to improve all three metrics; see `SELECTION_POLICY.md`.

## October 4 follow-up

| ID | Status | Change | Validation result |
|---|---|---|---|
| SW_0039 | held | Opt-in per-region dendritic transduction experiment | Peer per-region transfer was negative (plain sync .35 .3066/.4386/.2444 vs shared BIM6 .6211/.6680/.4255); do not launch pending checkpoint/data pairing and architecture review. See `peer_updates/REVIEW_0003_20261004.md` |
| SW_0040 | complete, diagnostic | Apply peer spike-synchrony components readout to frozen SW0038 spike5 seed0 and score HDF5 plus identity-mapped peer targets | At threshold .05 HDF5 .132102/.197586/.151268; peer targets .272610/.124795/.281338. Count exact 4.4%/5.6%; diagnostic only, not peer-checkpoint validation |
| SW_0041 | complete, shared BIM6 reproduction | Reproduce peer BIM6 seeds 0/1/2 using local training CLI | Peer validation T256 mean at threshold .20 .560392/.610688/.404574; T1024/512 threshold .10 mean .574026/.605911/.415638; seed0 collapsed. Same predictions on HDF5 are ~.0369/.2502/.1294. Epoch-1 direct peer loss matches. See SW0041 README and `peer_updates/REVIEW_0003_20261004.md` |
| SW_0042 | complete, seed2 collapse | HDF5-aligned BIM6 with verified factorized dynamics | Common long threshold .35 mean `.415879/.418226/.296118`; seed2 is about `.1857/.1352/.0370` and dominates variance. Lower training loss predicts worse task performance. See README. |
| SW_0043 | training and formal evaluation complete | Opt-in peer-exact factorized Kuramoto dynamics, seed-0 BIM6 | Epoch logs/learned tensors match peer; only unused `sc` differs. CPU T16 outputs are bitwise equal. Peer validation long at thresholds .10/.35: .640695/.632759/.463078 and .656050/.614347/.480345. See README/state-comparison JSON. |
| SW_0044 | complete, small 3-seed readout gain | Gaussian spatial weighting of spike-synchrony affinity on SW0042 | Best common long FG-ARI row sigma1.5/th.20 is `.418171/.414471/.301746`; best object-IoU row sigma1/th.10 is `.416896/.415005/.301948`. Seed2 collapse limits the mean. |
| SW_0045 | complete, strong seed0 learned signal | Stage-wise signal diagnostic on HDF5-aligned SW0042 seed 0 | Distance-controlled AUC phase/membrane/spike `.8567/.8410/.8355`; membrane-spatial spectral readout `.723731/.211605/.370475`. Signal degrades gradually downstream. |
| SW_0046 | complete, single-checkpoint reference audit | Official pretrained Slot Attention checkpoint on aligned HDF5 IDs 1320-1639 | .8946414575/.2235111789/.2459682554; prior IDs 1000-1319 .8901145722/.2122510283/.2354868700. Narrows seed0 gap to ARI; both IoUs exceed this single-checkpoint reference. Not a three-seed mean or goal success. |
| SW_0048 | prepared, not launched | Three-seed official Slot Attention candidate trained from scratch on HDF5 IDs 0-999 with 40-pass finite budget | Official reconstruction/Adam recipe adapted to 2500 steps, batch16, 11 slots and full uncropped images; each training image appears 40 times. Aligned validation uses SW0046 scoring on IDs1320-1639. See folder README. |
| SW_0049 | complete, upstream seed2 failure | Seed2 stage-wise collapse diagnostic | Distance-controlled AUC phase/membrane/spike `.4613/.4424/.4402`; binary threshold is constant one. Learned affinity is already below chance at phase and hurts the spatial readout. |
| SW_0050 | complete, two rescue tradeoffs | Seed2 cross-sample diversity versus low-LR model-training intervention | LR3e-4 long .35 is `.347156/.167773/.135250`; diversity/LR1e-3 is `.305639/.226015/.123898`; collapsed seed2 was `.185651/.135165/.036969`. Both rescue all metrics, with ARI/object vs foreground-IoU tradeoff. |
| SW_0051 | seed0 complete, tradeoff | Frozen spike-CC foreground with membrane/spike spatial spectral partitions | Long membrane-freeze `.630592/.606040/.449873` vs CC `.598427/.606040/.461779`; dynamic membrane `.588565/.606040/.465839`. Exact foreground mask retained, but no row dominates both grouping metrics. |
| SW_0052 | complete, low-LR epoch25 selected | Preflighted epoch20/25/30/35 trajectory screen for both SW0050 rescue arms | Long common .35 low-LR epoch25 `.395707/.189112/.159085` strictly dominates low-LR epoch40 `.347156/.167773/.135250`. Diversity epoch30/35 remain foreground-IoU tradeoffs. |
| SW_0053 | complete, new formal 3-seed lead | LR3e-4/epoch25 expansion to seeds0/1 plus seed2 LR1e-3/epoch25 control | Low-LR 3-seed mean is `.560105/.381852/.349261` at long .35 and `.562902/.381328/.356857` at .50. Seed2 low LR beats matched LR1e-3 epoch25 on all metrics; LR matters beyond stopping. |
| SW_0054 | complete seed0 count-32 pilot | Separated carrier, delayed-mask, and Kuramoto coupling interventions on aligned seed0 low-LR epoch25 | Gate permutation collapses spike readout without activity-scale collapse; carrier permutation is nearly neutral; K=0 causes a large drop. Pilot only; see validated results. |
| SW_0055 | complete, three-seed fixed contract | Expand unique train scenes from 1,000 to 2,500 while excluding held-out IDs1000-1639 | Long .50 means improved over SW0053 by +.063831/+.042012/+.083262 for FG-ARI/foreground IoU/matched-object IoU, with substantial seed spread. See validated summary. |
| SW_0056 | three CPU seeds active; CUDA seed1/2 acceleration queued | Matched-data Slot Attention candidate with 2,500 HDF5 train scenes and ten exact exposures each | 25,000 real exposures, 1,563 updates (1,562x16 plus an 8-image batch), official 11-slot/3-iteration recipe, aligned validation1320-1639. CPU seed0 stays authoritative; separate validated GPU reproductions can replace only slow seed1/2 outputs in the final summary. |
| SW_0057 | complete, three-seed fixed multi-readout | Compare spike CC and membrane spatial spectral on completed SW0055 checkpoints | Membrane readout reached FG-ARI .738478 but only .222631/.368848 IoUs, locating stable grouping signal before correct foreground/object overlap. |
| SW0057 scheduler | complete | Guarded post-SW0055 evaluation | All three checkpoint preflights, long evaluations, validators, and fixed summary completed on GPUs0/1. |
| SW0056 safety follow-up | complete on validated CUDA runner | Phase-aware matched Slot training, evaluation, and recovery | Three seeds completed the fixed 2,500-image x10-exposure contract; a missing validator argument was corrected and already-complete scoring artifacts were validated without recomputation. |
| SW0056 summary follow-up | complete baseline | Three-seed matched Slot Attention comparison | Mean `.571056/.225541/.171659` on aligned IDs1320-1639; per-seed provenance, exact slice, GT-free prediction, shared protocol family, and finite metrics all validate. |
| SW0058 | stage-1 stopped after seeds 0/1 | Loss intervention: component-spike-only training on fixed 1,000-scene data | Both seeds were lower than matched SW0053 baselines on FG-ARI, foreground IoU, and matched-object IoU at the registered long-window threshold. Seed2 was not launched. Complete removal of the phase-primary term is rejected under this contract. |
| SW_0054 result update | complete, seed0 32-image pilot | Gate-identity and coupling intervention | Raw pilot and validated summary pass the current validator. Normal spike-CC .6685/.6920/.4899; gate_perm_s0 .0055/.0880/.0278 with event-rate/membrane-variance ratios 1.0005/.9990; carrier_perm_s0 .6637/.6798/.4823; K0 .2377/.4388/.2212. Pilot only; do not generalize to full validation. |
| SW0058 evaluation follow-up | complete through registered stage-1 stop | Fixed short/long spike evaluation, real checkpoint smoke, SW0057 secondary readouts, and threshold-fixed comparison | Candidate deltas for seeds 0/1 were negative on every primary metric; see `SW_0058_component_spike_only_loss/results/stage1_seed0_seed1_stop.{json,md}`. |
| SW0059 | complete, mixed 32-image pilot | Centered delayed-gate validation-only pilot on SW0053 seed0 epoch25 | FG-ARI and matched-object IoU improved by .00925/.02150, while foreground IoU fell by .01704. The exact centered mode is not promoted directly to training. No retraining or data change. |
| SW0060 | complete, rejected 32-image pilot | Preserve per-component carrier while centering only the delayed mask | All three fixed metrics decreased slightly: FG-ARI -.000561, foreground IoU -.003384, matched-object IoU -.003590. No training or data change. |
| SW0061 | complete, direct feature substitution rejected | Label-free RGB/chroma/edge patch gamma on the fixed seed0 32-image pilot | Scored .308029/.383089/.190871, far below native autoencoder gamma .668520/.692026/.489879. A replacement encoder requires joint training or core adaptation. |
| SW0062 | complete, generic DINO direction stopped | Frozen DINOv2 patch features with training-only PCA and fresh core adaptation | Five-epoch pilot scored .612146/.182948/.363269; feature diagnostics showed worse CLEVR within-object consistency than native gamma, so no long training. |
| SW0063 | complete, endpoint gate failed | Label-free bilateral consistency in native gamma basis | Feature ratio improved .2254 to .2193 and FG-ARI rose +.0293, but both IoUs fell slightly; stopped before training. |
| SW0064 | complete, graph-to-Kuramoto bottleneck | Layer/time activation-flow probe comparing SW0055 seed0 and seed2 | Late PLV same-minus-different object margin is .8167 vs .5167; dendritic-to-membrane is nearly lossless, with a smaller membrane-to-spike loss. |
| SW0065 | complete, causal graph-generator diagnosis | Swap seed0 drive, learned graph, or Kuramoto state independently into seed2 | Only the graph swap rescues all three 32-image metrics: .3895/.2003/.1822 to .7036/.3081/.5376. |
| SW0066 | complete, mixed graph-stability gain | Fix only learned graph initialization to seed0 while retaining seed1/2 data order and all other initializations | Both weak seeds improve FG-ARI and object IoU; seed2 improves all three, but seed1 foreground IoU falls .0285, so the registered gate fails. |
| SW0067 | complete, adaptive-area classifier rejected | Calibrate synchrony threshold per image to a fixed .22 foreground coverage | Mean foreground IoU gains .0132, but FG-ARI/object IoU fall .1066/.0905 and count MAE worsens; stopped. |
| SW0068 | complete, joint co-adaptation rejected | Put the pretrained native RGB feature generator inside the differentiable core training path | Both joint arms lower all metrics. Swap diagnosis shows LR3e-5 features improve FG-ARI/object IoU in the old core, while the jointly updated core causes the IoU loss. |
| SW0069 | complete, feature-loss route stopped | Freeze SW0066 seed1 core and update only the encoder, with gamma anchor 0 vs 100 | Anchor100 limits drift and nearly preserves object IoU, but both arms remain below baseline on all three metrics. Existing binding loss is rejected for encoder tuning. |
| SW0070 | complete, new three-seed all-metric lead | Full 320-image long evaluation of SW0066 graph-init0 seeds1/2, combined with natural seed0 | `.677448/.435439/.479878`, improving SW0055 by `+.050715/+.012099/+.039759`; graph initialization is promoted as the stable-core baseline. |
| SW0071 | complete, grouping/object-IoU tradeoff | Preserve SW0070 spike foreground exactly and repartition only foreground patches with membrane/spike affinity | Spike-freeze raises internal FG-ARI `+.022007` with exact foreground preservation but lowers object IoU `-.033346`; no mode accepted. |
| SW0072 | complete, new three-seed all-metric lead | Load and freeze the successful trained seed0 graph generator while retraining seed1/2 downstream dynamics | Full mean `.781407/.478038/.616746`, beating SW0070 by `+.103960/+.042599/+.136868`; frozen graph remains bitwise exact. |
| SW0073 | complete, core co-adaptation rejected | Keep the trained seed0 graph frozen while jointly tuning aligned RGB features and downstream activation with phase-slot RGB reconstruction | No joint arm advances; weight1 features in the unchanged SW0072 core improve FG-ARI/object IoU to `.71894/.53055`, but foreground IoU falls to `.43119`. |
| SW0074 | complete, gamma-anchor route stopped | Freeze the full SW0072 seed1 core and tune only the RGB encoder with reconstruction weight1 and gamma anchors 10/100 | Both arms lower all metrics; smaller gamma drift does not preserve foreground IoU. Core/graph remain bitwise exact. |
| SW0075 | complete, foreground-IoU tradeoff | Freeze SW0072 core and preserve its patchwise settled membrane activity while reconstruction tunes grouping features | Weight10k scores `.706576/.477694/.500626` versus seed1 baseline `.708757/.468105/.509881`; only foreground IoU improves. Core/graph changes are zero; no arm advances. |
| SW0076 | complete, graph-anchor route stopped | Freeze SW0072 core and preserve its image-conditioned patch adjacency while reconstruction tunes the encoder | Weights1k/10k score `.680963/.419769/.500319` and `.667527/.442960/.505828`, both below the same SW0072 seed1 pilot on all metrics. No finer anchor sweep. |
| SW0077 | complete, classifier controls rejected | Compare gated versus binary-only component spikes and one GT-free RGB-border component veto on frozen SW0072 | Binary-only is empty because 98.82% of units are always on after settle. RGB veto changes `.708757/.468105/.509881` to `.476408/.515963/.311105`; foreground IoU rises but grouping/count collapse. |
| SW0078 | complete, RGB graph replacement rejected | Inject a label-free RGB bilateral graph at the causally identified graph-to-Kuramoto bottleneck, with the SW0072 core otherwise frozen | RGB-only and 25%/50% blends all lower all three metrics; learned graph baseline remains `.708757/.468105/.509881`. Generic color-distance topology does not explain the learned graph gain. |
| SW0079 | complete, learned-edge pruning rejected | Recompute the frozen SW0072 learned graph with coarse top-k 16/8 instead of 32, keeping all downstream dynamics fixed | Top-k16 `.635492/.460102/.461217` and top-k8 `.614964/.427776/.445628` both lower all metrics; weak learned edges are necessary for complete-object synchronization. |
| SW0080 | complete, graph reconstruction loss rejected | Starting from SW0072 seed1, train only the image-conditioned graph with existing phase/spike binding plus RGB phase-slot reconstruction weights .3/1.0 | `.682508/.464112/.492403` and `.667994/.471223/.492245`; neither advances. Non-graph core remains exact, so the current reconstruction loss is not a direct graph-edge teacher. |
| SW0081 | complete, mixed near-baseline pilot | Train only SW0072's graph so original and horizontally flipped images yield corresponding adjacencies, alongside existing phase/spike binding | Seed1 32-image 0.1x `.706200/.464029/.513687` versus baseline `.708757/.468105/.509881`; only object IoU improves. The 1x arm lowers all three. Inspect one 0.1x epoch trajectory, with no weight sweep or full promotion. |
| SW0082 | complete, equivariance direction stopped | Save and evaluate every epoch of the exact SW0081 0.1x arm | Epochs1--4 lower all three fixed pilot metrics; epoch5 exactly reproduces SW0081 `.706200/.464029/.513687` and improves only object IoU. No epoch advances, so stop weight/epoch sweeps and do not promote to full320. |
| SW0083 | complete, threshold direction stopped | Recalibrate only the frozen SW0072 membrane threshold after diagnosing saturated binary crossings | vth `.5/1/2` score `.595236/.330631/.481278`, `.016168/.029373/.026015`, and `0/0/0` versus `.06` baseline `.708757/.468105/.509881`. Temporal variation returns at `.5` but all metrics fall; useful structure is continuous gate amplitude here. |
| SW0084 | complete, joint route rejected | Jointly train aligned RGB encoder, learned graph, and complete downstream core with reconstruction weights 0/.3/1 and stable-core initialization control | No arm improves all three. Best-balanced A-epoch10 `.646381/.489311/.453914` raises foreground IoU only; C-epoch10 reaches `.630744` foreground IoU but lowers grouping/object IoU. |
| SW0085 | complete, gate bottleneck localized | Select the most balanced SW0084 checkpoint and compare its layer-resolved activation flow to SW0072 | A-epoch10 improves gamma/graph/Kuramoto margins, then loses `.057376` object margin at the gate; the loss persists through dendritic, membrane, and spike. No full320 promotion. |
| SW0086 | complete, mixed cross-contract transfer | Evaluate the best SW0072 seed0/1/2 cores unchanged on peer `clevr_with_masks` validation rows6000-6299 | Mean `.616852/.198362/.353836`: FG-ARI is `.002648` below peer Slot, while foreground/object IoU are `.074262/.261836` above; no retraining or peer-label tuning. |
| SW0087 | complete, matched Slot goal achieved | Compare completed SW0072 and matched-data SW0056 three-seed means under the aligned HDF5 contract | SW0072 beats Slot on all three: `.781407/.478038/.616746` vs `.571056/.225541/.171659`, deltas `+.210352/+.252498/+.445087`. |
| SW0088 | complete, metric tradeoff | Jointly train the native RGB encoder and SW0072 graph while freezing all downstream Kuramoto-to-spike tensors | Reconstruction `.3` raises object IoU `+.012681`; weight1 raises foreground IoU `+.016723`; both lower the other metrics, so downstream freezing limits collapse but does not preserve classifier affinity. |
| SW0089 | complete, metric tradeoff | Preserve the fixed classifier's centered component-gate affinity while encoder/graph reconstruction adapts | Weight100 reaches `.699688/.475970/.516505`, improving IoUs by `+.007865/+.006624` but lowering FG-ARI `.009069`; no arm improves all three. |
| SW0090 | complete, foreground gain with grouping tradeoff | Scale fixed-feature/frozen-graph recipe from 2,500 to 70,000 unique scenes | Three-seed epoch1 `.774323/.548028/.603848`, epoch3 `.752242/.548378/.614339`, epoch10 `.677605/.469147/.561948`; foreground IoU improves, other metrics do not beat SW0072. Three pre-registered image mask grids exported. |
| SW0092 | complete, all three seeds in both directions | Train our model on released Slot CLEVR6 and train Slot Attention on our 70,000 unique scenes | Epoch10 means: our-on-official `.740027/.566435/.603881`; Slot-on-our `.774933/.203589/.206937`. All 18 evaluations validated on our held-out IDs1320-1639. Official preprocessing yields 34,766 scenes. See TEST123_FINAL_RESULTS.md; pause requested after sharing. |
| SW0104 | complete diagnostic, strict checks partially fail | Explicit event/gate output-credit decomposition and fixed16 readout comparison on SW0097 frozen cores | Actual spikes reproduce archived metrics exactly; seed2 has four strict parameter-gradient sum failures, and gate scalar-formula discrepancies exceed 1e-6. Binary event readout is degenerate under Pearson because event traces are nearly constant. No training or full320 follow-up. See `SW_0104_causal_credit/README.md` and `results_archive/summary.json`. |
| SW0105 | training complete, full320 evaluation pending | Apply `event.detach() * actual_gate` only in the existing 5x spike auxiliary; preserve the actual event-times-gate forward and readout | All 3 seeds passed source/contract, direct-reference gradient, exact-forward, and finite B16 update preflights; all 256-update histories/checkpoints completed. A post-launch audit found overlap with another user's processes on GPUs0-3, preserved as a provenance limitation. Do not retrain; the owner-aware full320 evaluation queue is pending. See `SW_0105_event_detach_aux/README.md` and `results_archive/execution_control.json`. |
| SW0114 | seed0 pilot complete, no expansion | Compare 32x32 patches against the registered 16x16 endpoint | Pooled16 primary FG-ARI .644304 vs control .824754; native32 scores use a different contract. |
| SW0115 | complete, not promoted | Frozen-encoder analytic RGB partition credit | Candidate .825113/.719141/.654728; no clear FG gain and object IoU lower. |
| SW0116 | source endpoint audit, no new training | Validate live-encoder gamma against cached source | Source masks reproduce registered per-image metrics; live gamma endpoint reviewed for SW0117. |
| SW0117 | complete, not promoted | Joint encoder/graph/core analytic hard-partition RGB credit | Candidate .826210/.722913/.659548; fails +.01 FG gate against source and matched control. |
| SW0118 | complete, diagnostic only | Accept any instance pixel label present in a patch after prediction | Three-seed diagnostic .838763 ours vs .828048 own-data Slot; model-dependent GT/foreground sets, excluded from promotion. |
| SW0119 | complete, not promoted | Remove explicit target-density penalties from phase PLV and actual Q | .826622/.716248/.663776; FG gain +.000412 vs SW0117 with CI crossing zero. End recipe without tuning. |
| SW0120 | complete, not promoted | Guard backward for flat component traces without changing forward masks | .823662/.718524/.656108; extreme gradients suppressed, no demonstrated segmentation improvement. |
| SW0121 | completed seed0, not promoted | Training-only competitive spike assignment and detached-target Q consistency | Fixed320 .824101/.717444/.653268, below SW0117 and SW0097 on all metrics. Paired FG CIs cross zero; no seed fanout. |
| SW0122 | complete, not promoted | Three-seed joint analytic RGB replication | Candidate .767341/.574580/.594957 vs source .776348/.577070/.601537; paired FG CI against source negative; end recipe. |

| SW0109 recovery diagnostic | complete, single seed0 only | Existing N2500/N10000/N70000 checkpoints, equal4375updates; no retraining or historical completion certification | FG .822080/.819832/.818679; no demonstrated FG scaling gain in older frozen recipe. |

| SW0123 | all27 stages complete; failed pilot, closed | Adaptive temporal SNN + actual-spike CNN assignments and nativeRGB spatial decoder; matched legacy/gate-only controls registered | Adaptive primary mean .038607/.048265/.006983 vs source .776348/.577070/.601537; legacy QCC retains .770964FG; no70k expansion. |

| SW0124 | running read-only preflight/evaluation | Frozen97 actual512-settled-spike temporal prototypes,3 shared refinements,3seeds fixed320; compare originalQCC | Local/server14CPUtests pass; source/calbindings verified; supervisor1491982 live,GPU0 seed0preflight passed. No training or positive result yet. |

| SW0124 endpoint | complete; not promoted | All3 frozen-source temporal-prototype readouts,320sameimages | .751922/.397001/.552672; originalQCC exactly reproduced; all3FG lower, pairedCI[-.030902,-.017989]. Incumbent97 unchanged; no recipe expansion. |

| SW0125 | complete; no improvement | Full1024 forward with live64 late-gradient tail, same three source97 cores and loss | Three-seed mean .767077/.585208/.592722; FG-ARI below source97 on all seeds. Paired source FG delta CI [-.015291,-.003216]. Closed; incumbent97 retained. |

| SW0126 | complete; paired seed1 pilot failed, recipe closed | History-centered binary membrane events and full-temporal RGB assignment; matched gate-only head | Actual .365962/.249769/.194251 vs gate-only .436180/.393628/.241245 and source97 .742658/.590283/.584964. RGB losses decreased; all promotion gates failed. No seed or70k expansion; frozen-QCC attribution next. |

| SW0127 | local8tests passed; server deployment unconfirmed, no GPU job launched | Frozen original-QCC attribution: native97 control, untrained history adapter, both completed126 cores; seed1 same320 | Two-stage queue prepared. Fresh SSH read failed banner exchange; pending original transfer preserved for inspection. No new score or model promotion. |

| SW0127 resumed | server8tests and actual four-arm preflight passed; fixed320 evaluation live | GPU0 PID2211916, supervisor2211758; no optimizer updates | Six new files deployed after audited CLI-only SW0118 difference; existing helper unchanged. No new metric result yet. |

| SW0127 endpoint | complete, native coding restored for next branch | Same seed1 four frozen cores, original QCC fixed320; zero updates | Native97 .742658FG; untrained history .583412; trained history .588948; trained gate-core .578842. Source per-image scores exactly replayed. Both encoding/readout changes harmed fixed masks; no proof of all-gate usefulness or scaling. |

| SW0128 | completed scientific rejection; no training | Native97 all3 source spike/QCC relations frozen before GT,16VAL images each, near/mid directed eligible anchors | Local/server9tests passed; native rollout parity passed. All six seed/bin acceptance checks failed. Mid positive precision .8635/.7810/.7709, negatives .9903/.9819/.9873. Close self-teacher recipe without threshold tuning; incumbent unchanged. Supervisor2217736 and children2217752/2217878 terminal. |

| SW0129 | seed1 paired training live; seed2 scientific preflight rejection preserved | Posthoc exact SW0106 shared-RGB assignment-credit replication from SW0095; native actual-spike endpoint | Original106 gate remains failed. Server12tests and seed1 GPU preflight passed; seed2 row-scramble loss check rejected and no training. Separate guarded partial-resume server3tests passed; supervisor2230532, control2230556 GPU0/candidate2230557 GPU1 verified live. Both fixed256-update trainings followed by fixed320 evaluations queued. No3seed promotion or70k expansion from partial evidence. |

| SW0129 seed1 endpoint | complete; partial pair only | Seed1 candidate/control vs same-seed SW0097, fixed320 native QCC | Candidate .745931/.577300/.586313; control .735055/.591783/.578880; source .742658/.590283/.584964. Candidate-source FG paired CI [-.006695,.012840]; seed2 row-scramble scientific rejection preserved. No 3-seed promotion, gate-contribution, or scaling claim. |

| SW0130 | scientific TRAIN preflight failure; no paired training | Phase-conditioned dendritic/membrane state integration vs same-capacity constant integration; native source97 QCC retained | Actual seeds0/1 passed; seed2 warmed-decoder H row scramble failed. Frozen guard preserved. All queue PIDs terminal. Raw JSON/log: SW_0130_phase_state_integration/results_archive/terminal_preflight_20261009/. No new segmentation score or gating/scaling claim. |

| SW0130 preflight code | deployed and tested; scientific outcome recorded above | Local and server12 CPU tests passed; separate draft train/eval5 local tests passed | Train/eval drafts were not deployed or executed because the all-three scientific gate failed. |
| SW0131 | all3 read-only TRAIN diagnostics complete | Native H vs registered row-shuffle vs assignment-independent image-mean content; initial and warmed32 decoder | Warmed32 image-mean RGB MSE differences vs native: +0.9688% s0,+0.1545% s1,-0.2520% s2. Seed2 reconstruction improved while assignment utility inverted. No optimizer updates or segmentation evaluation. Raw evidence: SW_0131_decoder_partition_diagnosis/results_archive/completed_20261009/. |

| SW0132 | relative fullRGB decoder implemented; local5 tests passed; preflight implementation in progress | Live W-derived centroid/footprint variance and pooled gamma; relative pixel coordinates, no separate absoluteXY or alpha; checkpointed1024pixel render+mixture | Source97/SW13012scalar phase-vs-constant and actual-spike QCC retained. New all3TRAIN screens required before paired pilot. No GPU/model metric yet. |


## Verified updates: 2026-10-15

- [SW0165](SW_0165_foreground_partition_replication/RESULT_KO.md): frozen native32 readout, three-seed .804299/.609975/.651149; all three metric means exceed matched Slot on fixed320. Independent full recomputation passed.
- [SW0166](SW_0166_fixed_support_ari_diagnosis/RESULT_KO.md): postscore fixed-support ARI bound and merge/split diagnosis; GT-assisted values are diagnostics. Independent full recomputation passed.
- [SW0167](SW_0167_structured_relation_energy/DESIGN_KO.md): conditional supervised structured-energy proposal; wait for final SW0163 classifier comparison before selecting the next test. Not running.
