#!/usr/bin/env python3
"""Read-only CPU extraction for three fixed rows of official CLEVR train export.

The program writes nothing on the server. It emits one JSON line whose NPZ
payload is base64; redirect stdout to a private local file when running it.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import sys
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["OMP_NUM_THREADS"] = "2"

MODEL_DIR = Path("/Data0/kevinswk/patch_v2/trained_models/slot_attention_official_patch_eval_20261002")
CHECKPOINT = MODEL_DIR / "checkpoint" / "ckpt-500"
DATA_PATH = Path("/Data0/kevinswk/patch_v2_sw/data/SW_0092_cross_dataset/official_clevr6_train.hdf5")
EXPORT_MANIFEST = DATA_PATH.parent / "official_clevr6_manifest.json"
ROWS = (0, 1, 2)
SEED = 0
SLOTS = 7
ITERATIONS = 3
RESOLUTION = (128, 128)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def modal4(labels):
    import numpy as np
    if labels.shape != (3, 128, 128):
        raise ValueError(f"native labels have unexpected shape {labels.shape}")
    blocks = labels.reshape(3, 32, 4, 32, 4).transpose(0, 1, 3, 2, 4).reshape(3, 32, 32, 16)
    counts = np.stack([(blocks == slot).sum(axis=-1) for slot in range(SLOTS)], axis=-1)
    # argmax resolves ties to the smallest original slot id.
    return counts.argmax(axis=-1).astype(np.uint8)


def main() -> None:
    import h5py
    import numpy as np
    import tensorflow as tf

    tf.config.threading.set_inter_op_parallelism_threads(2)
    tf.config.threading.set_intra_op_parallelism_threads(1)
    if tf.config.list_physical_devices("GPU"):
        raise RuntimeError("CPU-only extraction expected, but TensorFlow sees a GPU")
    if not DATA_PATH.is_file() or not EXPORT_MANIFEST.is_file() or not (CHECKPOINT.parent / (CHECKPOINT.name + ".index")).is_file():
        raise FileNotFoundError("registered training export or checkpoint is missing")
    model_path = MODEL_DIR / "model.py"
    sys.path.insert(0, str(MODEL_DIR))
    import model as model_utils

    tf.random.set_seed(SEED)
    model = model_utils.build_model(
        RESOLUTION, batch_size=1, num_slots=SLOTS, num_iterations=ITERATIONS,
        model_type="object_discovery")
    checkpoint = tf.train.Checkpoint(network=model)
    status = checkpoint.restore(str(CHECKPOINT))
    status.assert_existing_objects_matched()
    status.expect_partial()

    with h5py.File(DATA_PATH, "r") as data:
        required = {"image", "tfds_train_index", "num_actual_objects"}
        if not required.issubset(data.keys()):
            raise KeyError(f"training export is missing required datasets: {sorted(required - set(data.keys()))}")
        if data["image"].shape[0] < max(ROWS) + 1:
            raise ValueError("official training export has fewer than three rows")
        raw = np.asarray(data["image"][list(ROWS)])
        train_indices = np.asarray(data["tfds_train_index"][list(ROWS)]).reshape(-1)
        object_counts = np.asarray(data["num_actual_objects"][list(ROWS)]).reshape(-1)
    if raw.shape != (3, 128, 128, 3) or raw.dtype != np.float16:
        raise ValueError(f"unexpected official image schema: shape={raw.shape}, dtype={raw.dtype}")
    if not np.isfinite(raw).all() or raw.min() < 0 or raw.max() > 1:
        raise ValueError("official images are not finite float16 RGB in [0,1]")

    # The registered export has already applied crop [29:221,64:256] and
    # bilinear resize to 128x128 and stores float16 RGB in [0,1].
    tensor = tf.convert_to_tensor(raw, dtype=tf.float32) * 2.0 - 1.0

    originals, reconstructions, slot_reconstructions, masks = [], [], [], []
    hard_labels = []
    for row in range(3):
        image = tensor[row:row + 1]
        recon, slot_recon, soft_masks, _ = model(image, training=False)
        original01 = tf.clip_by_value(image[0] * 0.5 + 0.5, 0.0, 1.0)
        recon01 = tf.clip_by_value(recon[0] * 0.5 + 0.5, 0.0, 1.0)
        slot_recon01 = tf.clip_by_value(slot_recon[0] * 0.5 + 0.5, 0.0, 1.0)
        soft = tf.squeeze(soft_masks[0], axis=-1)  # [7,128,128]
        if tuple(soft.shape) != (SLOTS, 128, 128):
            raise ValueError(f"unexpected soft-mask shape {tuple(soft.shape)}")
        if not all(bool(tf.reduce_all(tf.math.is_finite(x))) for x in (original01, recon01, slot_recon01, soft)):
            raise ValueError("model produced non-finite display tensors")
        originals.append(original01.numpy())
        reconstructions.append(recon01.numpy())
        slot_reconstructions.append(slot_recon01.numpy())
        masks.append(tf.transpose(soft, [1, 2, 0]).numpy())  # [128,128,7]
        hard_labels.append(tf.argmax(soft, axis=0, output_type=tf.int32).numpy())

    originals = np.asarray(originals, dtype=np.float32)
    reconstructions = np.asarray(reconstructions, dtype=np.float32)
    slot_reconstructions = np.asarray(slot_reconstructions, dtype=np.float32)
    masks = np.asarray(masks, dtype=np.float32)
    hard128 = np.asarray(hard_labels, dtype=np.uint8)
    hard32 = modal4(hard128)
    if not np.allclose(masks.sum(axis=-1), 1.0, atol=2e-5):
        raise ValueError("slot masks do not sum to one at each pixel")

    buf = io.BytesIO()
    np.savez_compressed(
        buf,
        export_rows=np.asarray(ROWS, dtype=np.int64),
        tfds_train_index=train_indices.astype(np.int64),
        num_actual_objects=object_counts.astype(np.int64),
        rgb_uint8=np.rint(originals * 255.0).clip(0, 255).astype(np.uint8),
        reconstruction=reconstructions.astype(np.float32),
        slot_reconstruction=slot_reconstructions.astype(np.float32),
        soft_masks=masks,
        hard_labels128=hard128,
        modal_labels32=hard32,
    )
    selected_rows_hash = hashlib.sha256(raw.tobytes(order="C")).hexdigest()
    data_stat = DATA_PATH.stat()
    checkpoint_hashes = {
        str(path.name): sha256_file(path)
        for path in (CHECKPOINT.parent / (CHECKPOINT.name + ".index"),
                     CHECKPOINT.parent / (CHECKPOINT.name + ".data-00000-of-00001"))
    }
    metadata = {
        "status": "extraction_complete",
        "purpose": "visualize released Slot Attention checkpoint on its own official CLEVR6 training export",
        "selection": "fixed first three export rows (0,1,2), not selected by image quality",
        "training_split": "official_clevr6_train.hdf5; no GT masks or labels read",
        "source_rows": list(ROWS),
        "tfds_train_index": train_indices.astype(int).tolist(),
        "num_actual_objects": object_counts.astype(int).tolist(),
        "seed": SEED,
        "batch_size": 1,
        "num_slots": SLOTS,
        "num_iterations": ITERATIONS,
        "input_resolution": list(RESOLUTION),
        "preprocessing": "official export already applied crop [29:221,64:256] and bilinear resize128; stored float16 RGB [0,1] converted to [-1,1] for model input",
        "checkpoint_prefix": str(CHECKPOINT),
        "checkpoint_files_sha256": checkpoint_hashes,
        "model_path": str(model_path),
        "model_sha256": sha256_file(model_path),
        "training_export_path": str(DATA_PATH),
        "training_export_manifest_path": str(EXPORT_MANIFEST),
        "training_export_manifest_sha256": sha256_file(EXPORT_MANIFEST),
        "training_export_file_size_bytes": data_stat.st_size,
        "training_export_mtime_ns": data_stat.st_mtime_ns,
        "selected_input_rows_sha256": selected_rows_hash,
        "output_shapes": {
            "rgb_uint8": [3, 128, 128, 3],
            "reconstruction": [3, 128, 128, 3],
            "slot_reconstruction": [3, 7, 128, 128, 3],
            "soft_masks": [3, 128, 128, 7],
            "hard_labels128": [3, 128, 128],
            "modal_labels32": [3, 32, 32],
        },
        "mask_semantics": "soft_masks retain original checkpoint slot IDs 0..6; hard labels are argmax; modal labels use 4x4 majority, ties to lowest original slot ID",
        "claims": "visualization only; no GT segmentation score, no quality selection, no model comparison",
        "gpu_used": False,
        "optimizers_or_updates": False,
    }
    result = {"metadata": metadata, "npz_sha256": hashlib.sha256(buf.getvalue()).hexdigest(),
              "npz_base64": base64.b64encode(buf.getvalue()).decode("ascii")}
    print(json.dumps(result, separators=(",", ":"), allow_nan=False))


if __name__ == "__main__":
    main()
