#!/usr/bin/env python3
"""Render a private extraction NPZ from the released Slot Attention checkpoint."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import io
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np


def _load(bundle_path: Path | None, metadata_path: Path | None, extraction_json: Path | None = None):
    if extraction_json is not None:
        wrapper = json.loads(extraction_json.read_text(encoding="utf-8-sig"))
        payload = base64.b64decode(wrapper["npz_base64"], validate=True)
        if hashlib.sha256(payload).hexdigest() != wrapper.get("npz_sha256"):
            raise ValueError("extraction NPZ payload hash mismatch")
        metadata = wrapper["metadata"]
        source = io.BytesIO(payload)
    else:
        if bundle_path is None or metadata_path is None:
            raise ValueError("provide --extraction-json or both --bundle and --metadata")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8-sig"))
        source = bundle_path
    if metadata.get("status") != "extraction_complete":
        raise ValueError("extraction metadata is not complete")
    if metadata.get("num_slots") != 7 or metadata.get("source_rows") != [0, 1, 2]:
        raise ValueError("bundle does not match the registered first-three, seven-slot recipe")
    with np.load(source, allow_pickle=False) as data:
        required = {
            "export_rows", "tfds_train_index", "num_actual_objects", "rgb_uint8",
            "reconstruction", "slot_reconstruction", "soft_masks",
            "hard_labels128", "modal_labels32",
        }
        if not required.issubset(data.files):
            raise ValueError(f"missing NPZ fields: {sorted(required - set(data.files))}")
        arrays = {name: data[name] for name in required}
    shapes = {
        "export_rows": (3,), "tfds_train_index": (3,), "num_actual_objects": (3,),
        "rgb_uint8": (3, 128, 128, 3), "reconstruction": (3, 128, 128, 3),
        "slot_reconstruction": (3, 7, 128, 128, 3), "soft_masks": (3, 128, 128, 7),
        "hard_labels128": (3, 128, 128), "modal_labels32": (3, 32, 32),
    }
    for name, expected in shapes.items():
        if arrays[name].shape != expected:
            raise ValueError(f"{name} shape {arrays[name].shape} != {expected}")
    if not np.array_equal(arrays["export_rows"], np.arange(3)):
        raise ValueError("bundle rows are not the registered fixed rows 0,1,2")
    if not np.array_equal(arrays["tfds_train_index"], metadata["tfds_train_index"]):
        raise ValueError("metadata and NPZ TFDS indices differ")
    if not np.isfinite(arrays["reconstruction"]).all() or not np.isfinite(arrays["soft_masks"]).all():
        raise ValueError("non-finite model output")
    if arrays["rgb_uint8"].dtype != np.uint8:
        raise ValueError("display RGB must be uint8")
    if arrays["hard_labels128"].min() < 0 or arrays["hard_labels128"].max() >= 7:
        raise ValueError("native hard labels outside original slot IDs 0..6")
    if arrays["modal_labels32"].min() < 0 or arrays["modal_labels32"].max() >= 7:
        raise ValueError("modal labels outside original slot IDs 0..6")
    return metadata, arrays


def _palette():
    # Colors identify original slot IDs; slot 0 is not assigned special
    # background semantics and no label matching is performed.
    colors = ["#222222", "#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#a65628"]
    return ListedColormap(colors, name="original_slot_ids")


def _draw_one(metadata, a, i: int, output_path: Path):
    image = a["rgb_uint8"][i]
    recon = np.clip(a["reconstruction"][i], 0.0, 1.0)
    hard = a["hard_labels128"][i]
    labels32 = a["modal_labels32"][i]
    masks = a["soft_masks"][i]
    slot_recon = np.clip(a["slot_reconstruction"][i], 0.0, 1.0)
    cmap = _palette()

    fig = plt.figure(figsize=(21, 10), constrained_layout=True)
    grid = fig.add_gridspec(3, 1, height_ratios=(1.0, 0.8, 1.0))
    top_grid = grid[0].subgridspec(1, 4)
    top = [fig.add_subplot(top_grid[0, j]) for j in range(4)]
    top[0].imshow(image)
    top[0].set_title("Official train image")
    top[1].imshow(recon)
    top[1].set_title("Reconstruction")
    top[2].imshow(hard, cmap=cmap, vmin=0, vmax=6, interpolation="nearest")
    top[2].set_title("128×128 hard masks\nargmax, original slot IDs")
    top[3].imshow(labels32, cmap=cmap, vmin=0, vmax=6, interpolation="nearest")
    top[3].set_title("32×32 modal masks\n4×4 majority; ties → lowest ID")
    for ax in top:
        ax.axis("off")

    # All soft masks are shown, including empty or tiny slots.
    for slot in range(7):
        ax = fig.add_subplot(grid[1].subgridspec(1, 7)[0, slot])
        ax.imshow(masks[..., slot], cmap="gray", vmin=0.0, vmax=1.0)
        ax.set_title(f"Soft mask · ID {slot}")
        ax.axis("off")
    recon_grid = grid[2].subgridspec(1, 7)
    for slot in range(7):
        ax = fig.add_subplot(recon_grid[0, slot])
        composite = slot_recon[slot] * masks[..., slot, None] + (1.0 - masks[..., slot, None])
        ax.imshow(np.clip(composite, 0.0, 1.0))
        ax.set_title(f"Masked slot recon · ID {slot}")
        ax.axis("off")

    row = int(a["export_rows"][i])
    tfds_id = int(a["tfds_train_index"][i])
    count = int(a["num_actual_objects"][i])
    fig.suptitle(
        f"Released Slot Attention checkpoint on official training row {row} "
        f"(TFDS train index {tfds_id}; recorded object count {count})\n"
        "Colors/IDs are the model's original slot IDs; no GT masks or label matching used",
        fontsize=13,
    )
    fig.savefig(output_path, dpi=160, facecolor="white")
    plt.close(fig)


def _draw_overview(a, output_path: Path):
    fig, axes = plt.subplots(3, 4, figsize=(14, 10), constrained_layout=True)
    cmap = _palette()
    for i in range(3):
        axes[i, 0].imshow(a["rgb_uint8"][i])
        axes[i, 0].set_title(f"Train image · row {int(a['export_rows'][i])}")
        axes[i, 1].imshow(np.clip(a["reconstruction"][i], 0, 1))
        axes[i, 1].set_title("Reconstruction")
        axes[i, 2].imshow(a["hard_labels128"][i], cmap=cmap, vmin=0, vmax=6, interpolation="nearest")
        axes[i, 2].set_title("Native 128×128 slot IDs")
        axes[i, 3].imshow(a["modal_labels32"][i], cmap=cmap, vmin=0, vmax=6, interpolation="nearest")
        axes[i, 3].set_title("Modal 32×32 slot IDs")
        for ax in axes[i]:
            ax.axis("off")
    fig.suptitle(
        "Released checkpoint · its official CLEVR training export · fixed first three rows\n"
        "Colors identify original slot IDs only; no slot is designated as background and no GT labels are used",
        fontsize=14,
    )
    fig.savefig(output_path, dpi=170, facecolor="white")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, help="decoded extraction .npz")
    parser.add_argument("--metadata", type=Path, help="extraction metadata JSON")
    parser.add_argument("--extraction-json", type=Path, help="captured extractor stdout JSON containing NPZ base64")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    metadata, arrays = _load(args.bundle, args.metadata, args.extraction_json)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for i in range(3):
        _draw_one(metadata, arrays, i, args.output_dir / f"official_train_row_{i}.png")
    _draw_overview(arrays, args.output_dir / "overview.png")
    print(json.dumps({
        "status": "render_complete",
        "images": [str(args.output_dir / f"official_train_row_{i}.png") for i in range(3)],
        "overview": str(args.output_dir / "overview.png"),
        "source_rows": [0, 1, 2],
        "note": "visualization only; no GT metrics or quality selection",
    }, indent=2))


if __name__ == "__main__":
    main()
