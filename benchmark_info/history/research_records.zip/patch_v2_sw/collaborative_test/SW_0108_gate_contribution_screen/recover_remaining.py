"""Review-gated recovery supervisor for the two interrupted SW0108 readouts.

This does not modify source/configuration or the original SW0108 queue state.
It is intentionally opt-in; without --run it only validates readiness and prints
the two exact registered CLI commands. Each run uses a fresh attempt folder.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

try:
    import fcntl
except ImportError:  # The reviewed operation is executable only on the Linux server.
    fcntl = None

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import coordinator as old_queue
from run import (BASELINE_REFERENCE, BASELINE_REFERENCE_SHA256,
                 SOURCE_DEFAULT, sha)

STATE = HERE / "results_archive/queue_state.json"
OUT = ROOT / "trained_models/SW0108_gate_contribution_screen"
GAMMA_DEFAULT = Path(
    "/Data0/kevinswk/patch_v2_sw/data/SW_0042_hdf5_aligned/gamma_validation_1320_1639.pt")
DEFAULT_DATASET = Path("/Data0/kevinswk/datasets/object_centric_data/clevr_10-full.hdf5")
RUNNER = HERE / "run.py"
LEASE_DIR = Path("/tmp/kevinswk_sw0113_gpu_leases")
EXPECTED_ARMS = ("baseline", "kuramoto_K0", "constant_gate_half", "dendrite_no_retention")
REMAINING_ARMS = ("membrane_no_retention", "events_forced_on")
EXPECTED_ACTIVE = {"stage": "evaluate", "arm": "membrane_no_retention", "pid": 539128, "gpu": 0}
EXPECTED_108_PARENT = 286741
EXPECTED_109_PARENT = 287264
MAX_RESOURCE_INTERRUPTS = 3
POLL_SECONDS = 5


def atomic_json(path: Path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temp, path)


def read_state(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pid_identity(pid):
    result = subprocess.run(["ps", "-p", str(pid), "-o", "uid=,args="],
                            capture_output=True, text=True, check=False)
    line = result.stdout.strip()
    return line if result.returncode == 0 and line else None


def assert_pid_absent(pid, label):
    identity = pid_identity(pid)
    if identity is not None:
        raise RuntimeError(f"expected terminal {label} PID {pid}, still present: {identity}")


def assert_109_idle(pid):
    identity = pid_identity(pid)
    if not identity or "SW_0109_unique_data_scaling/coordinator.py --run" not in identity:
        raise RuntimeError(f"SW0109 PID {pid} identity changed or disappeared: {identity}")
    uid_text = identity.split(None, 1)[0]
    if uid_text != str(os.getuid()):
        raise RuntimeError(f"SW0109 coordinator UID differs from this user: {identity}")
    children = old_queue.descendants(pid) - {pid}
    if children:
        raise RuntimeError(f"SW0109 is no longer idle; preserving children {sorted(children)}")


def verified_context(state_path=STATE, source=SOURCE_DEFAULT,
                     gamma=GAMMA_DEFAULT, dataset=DEFAULT_DATASET,
                     parent108=EXPECTED_108_PARENT, worker108=EXPECTED_ACTIVE["pid"],
                     parent109=EXPECTED_109_PARENT):
    state = read_state(state_path)
    if state.get("status") != "error" or state.get("pending") != [] or state.get("failed") is not None:
        raise RuntimeError("SW0108 durable queue state changed; do not resume")
    active = state.get("active", {})
    if (active.get("pid") != EXPECTED_ACTIVE["pid"] or active.get("gpu") != EXPECTED_ACTIVE["gpu"]
            or active.get("task", {}).get("stage") != EXPECTED_ACTIVE["stage"]
            or active.get("task", {}).get("arm") != EXPECTED_ACTIVE["arm"]):
        raise RuntimeError("SW0108 stale-active record does not match audited interrupted membrane task")
    for pid, label in ((state.get("queue_pid"), "recorded SW0108 queue"),
                       (parent108, "SW0108 coordinator"), (worker108, "SW0108 evaluation worker")):
        if pid is not None:
            assert_pid_absent(int(pid), label)
    assert_109_idle(parent109)

    if state.get("source_checkpoint") != str(Path(source)) or sha(source) != state.get("source_sha256"):
        raise RuntimeError("SW0108 source checkpoint path/SHA changed")
    if state.get("gamma_path") != str(Path(gamma)) or sha(gamma) != state.get("gamma_sha256"):
        raise RuntimeError("SW0108 fixed validation gamma path/SHA changed")
    if state.get("dataset_path") != str(Path(dataset)):
        raise RuntimeError("SW0108 dataset path changed")
    st = Path(dataset).stat()
    if state.get("dataset_identity") != {"size_bytes": st.st_size, "mtime_ns": st.st_mtime_ns}:
        raise RuntimeError("SW0108 dataset identity changed")
    if sha(RUNNER) != state.get("runner_sha256"):
        raise RuntimeError("deployed SW0108 runner differs from failed queue provenance")
    shared = ROOT / "collaborative_test/SW_0040_peer_transfer/evaluate.py"
    if sha(shared) != state.get("shared_evaluator_sha256"):
        raise RuntimeError("shared evaluation code differs from failed queue provenance")
    if sha(HERE / "protocol.json") != state.get("protocol_sha256"):
        raise RuntimeError("SW0108 protocol differs from failed queue provenance")
    if (state.get("registered_baseline_reference") != str(BASELINE_REFERENCE.resolve())
            or state.get("registered_baseline_reference_sha256") != BASELINE_REFERENCE_SHA256
            or state.get("registered_baseline_expected_sha256") != BASELINE_REFERENCE_SHA256
            or sha(BASELINE_REFERENCE) != BASELINE_REFERENCE_SHA256):
        raise RuntimeError("SW0108 frozen SW0097 baseline reference/SHA differs from queue provenance")

    preflight = HERE / "results_archive/preflight_seed0.json"
    if not old_queue.valid_result("all", preflight):
        raise RuntimeError("completed SW0108 preflight no longer validates")
    for arm in EXPECTED_ARMS:
        if not old_queue.valid_result(arm, OUT / arm):
            raise RuntimeError(f"completed SW0108 arm no longer validates: {arm}")
    # valid_result('baseline', ...) calls run.baseline_match, which verifies
    # the frozen SW0097 reference SHA plus exact per-image and aggregate metrics.
    attempts = state.get("attempts", [])
    completed_arms = [row.get("task", {}).get("arm") for row in attempts
                      if row.get("task", {}).get("stage") == "evaluate" and row.get("valid") is True]
    if completed_arms != list(EXPECTED_ARMS):
        raise RuntimeError(f"completed arm provenance changed: {completed_arms}")
    partial = OUT / "membrane_no_retention"
    if partial.exists() and any(partial.iterdir()):
        raise RuntimeError("canonical interrupted membrane directory is nonempty; preserve and review it")
    events = OUT / "events_forced_on"
    if events.exists() and any(events.iterdir()):
        raise RuntimeError("canonical events directory is nonempty; preserve and review it")
    for path in (source, gamma, dataset):
        if not Path(path).is_file():
            raise FileNotFoundError(path)
    return state


def worker_argv(arm, output_dir, source, gamma, dataset):
    return [sys.executable, str(RUNNER), "--stage", "evaluate", "--arm", arm,
            "--checkpoint", str(Path(source)), "--gamma-path", str(Path(gamma)),
            "--dataset-path", str(Path(dataset)), "--output-dir", str(output_dir),
            "--device", "cuda:0"]


def wait_for_gpu(reservations, wait_seconds=POLL_SECONDS):
    if fcntl is None:
        raise RuntimeError("SW0108 recovery requires Linux fcntl GPU leases")
    while True:
        for gpu in old_queue.available_gpus():
            if gpu in reservations:
                continue
            # Cross-process lock shared with the reviewed central dispatcher.
            LEASE_DIR.mkdir(parents=True, exist_ok=True)
            lease_path = LEASE_DIR / f"gpu{gpu}.lock"
            stream = lease_path.open("a+")
            try:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                stream.close()
                continue
            # Recheck ownership/memory after taking the lease, before CUDA start.
            if old_queue.owners(gpu) or old_queue.memory(gpu) > old_queue.MAX_USED_MIB:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
                stream.close()
                continue
            reservations.add(gpu)
            return gpu, stream, lease_path
        time.sleep(wait_seconds)


def release_gpu(gpu, stream, reservations):
    reservations.discard(gpu)
    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
    stream.close()


def execute_arm(arm, source, gamma, dataset, receipt_state, reservations):
    interruptions = 0
    while interruptions < MAX_RESOURCE_INTERRUPTS:
        gpu, lease_stream, lease_path = wait_for_gpu(reservations)
        prior = sum(row.get("arm") == arm for row in receipt_state["attempts"])
        attempt_id = f"{arm}_attempt{prior + 1}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
        attempt_root = OUT / "recovery_attempts"
        output = attempt_root / attempt_id
        log = attempt_root / f"{attempt_id}.log"
        if output.exists() or log.exists():
            release_gpu(gpu, lease_stream, reservations)
            raise FileExistsError(f"fresh attempt path already exists: {output}")
        output.parent.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), OMP_NUM_THREADS="2",
                   MKL_NUM_THREADS="2",
                   TRITON_CACHE_DIR="/tmp/kevinswk_sw0108_triton_recovery")
        owners_before = {str(g): old_queue.owners(g) for g in old_queue.GPUS}
        # Last ownership check immediately before process creation.
        if old_queue.owners(gpu) or old_queue.memory(gpu) > old_queue.MAX_USED_MIB:
            release_gpu(gpu, lease_stream, reservations)
            continue
        entry = {"arm": arm, "attempt_id": attempt_id, "output_dir": str(output),
                 "log": str(log), "gpu": gpu, "lease_path": str(lease_path),
                 "owners_before": owners_before, "started": time.time(), "status": "running"}
        receipt_state["attempts"].append(entry)
        atomic_json(OUT / "recovery_attempts/recovery_state.json", receipt_state)
        interrupted = False
        proc = None
        try:
            with log.open("x", encoding="utf-8") as stream:
                proc = subprocess.Popen(worker_argv(arm, output, source, gamma, dataset),
                    cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, env=env, start_new_session=True)
                entry["pid"] = proc.pid
                atomic_json(OUT / "recovery_attempts/recovery_state.json", receipt_state)
                while proc.poll() is None:
                    foreign = [pid for pid in old_queue.owners(gpu)
                               if pid not in old_queue.descendants(proc.pid)]
                    if foreign:
                        old_queue.stop_owned(proc)
                        entry.update({"status": "interrupted_foreign_owner", "foreign_pids": foreign,
                                      "return_code": proc.returncode, "finished": time.time()})
                        interrupted = True
                        break
                    time.sleep(2)
            if not interrupted:
                valid = proc.returncode == 0 and old_queue.valid_result(arm, output)
                entry.update({"status": "complete" if valid else "failed",
                              "return_code": proc.returncode, "valid_result": bool(valid),
                              "finished": time.time()})
                atomic_json(OUT / "recovery_attempts/recovery_state.json", receipt_state)
                if not valid:
                    raise RuntimeError(f"{arm} evaluation failed; attempt preserved at {output}")
                return entry
        finally:
            if proc is not None and proc.poll() is None:
                old_queue.stop_owned(proc)
            release_gpu(gpu, lease_stream, reservations)
        if interrupted:
            interruptions += 1
            entry["resource_interruption_number"] = interruptions
            atomic_json(OUT / "recovery_attempts/recovery_state.json", receipt_state)
            time.sleep(POLL_SECONDS)
    return {"arm": arm, "status": "resource_retry_limit_reached",
            "resource_interruptions_this_review": interruptions,
            "limit": MAX_RESOURCE_INTERRUPTS}


def run_recovery(args):
    state = verified_context(args.state, args.source, args.gamma, args.dataset,
                             args.expected_108_parent, args.expected_108_worker,
                             args.expected_109_parent)
    recovery_state_path = OUT / "recovery_attempts/recovery_state.json"
    receipt_path = HERE / "results_archive/recovery_remaining_receipt.json"
    if receipt_path.exists():
        raise FileExistsError("preserve existing SW0108 recovery receipt")
    if recovery_state_path.exists():
        if not args.resume:
            raise FileExistsError("preserve existing SW0108 recovery state; use explicit --resume only after review")
        state_record = read_state(recovery_state_path)
        if (state_record.get("status") != "resource_retry_limit_reached"
                or state_record.get("original_queue_state_sha256") != sha(args.state)
                or state_record.get("source_sha256") != state["source_sha256"]
                or state_record.get("gamma_sha256") != state["gamma_sha256"]
                or state_record.get("runner_sha256") != state["runner_sha256"]
                or state_record.get("protocol_sha256") != state["protocol_sha256"]):
            raise RuntimeError("existing recovery state is not eligible for reviewed resource-only resumption")
        state_record.setdefault("reviewed_resumptions", []).append({"at": time.time(), "pending": list(state_record.get("pending_arms", []))})
    else:
        if args.resume:
            raise FileNotFoundError("--resume requires a preserved resource_retry_limit_reached state")
        state_record = {"experiment": "SW0108", "status": "recovering_remaining_evaluations",
                        "original_queue_state_sha256": sha(args.state),
                        "source_sha256": state["source_sha256"], "gamma_sha256": state["gamma_sha256"],
                        "runner_sha256": state["runner_sha256"],
                        "shared_evaluator_sha256": state["shared_evaluator_sha256"],
                        "protocol_sha256": state["protocol_sha256"],
                        "remaining_arms": list(REMAINING_ARMS), "attempts": [],
                        "created": time.time(), "queue_state_modified": False,
                        "reviewed_resumptions": []}
    if not args.run:
        commands = {arm: worker_argv(arm, OUT / "recovery_attempts" / f"{arm}_<unique>",
                                     args.source, args.gamma, args.dataset)
                    for arm in REMAINING_ARMS}
        print(json.dumps({"status": "ready", "original_queue_state_sha256": sha(args.state),
                          "source_sha256": state["source_sha256"], "gamma_sha256": state["gamma_sha256"],
                          "validated_prior_arms": list(EXPECTED_ARMS), "remaining_arms": commands,
                          "execute_requires_reviewed_run_flag": True}, indent=2))
        return
    state_record["status"] = "waiting_for_free_gpu"
    atomic_json(recovery_state_path, state_record)
    reservations = set()
    try:
        complete_arms = {row.get("arm") for row in state_record["attempts"]
                         if row.get("status") == "complete" and row.get("valid_result") is True}
        pending_arms = [arm for arm in REMAINING_ARMS if arm not in complete_arms]
        for arm in pending_arms:
            state_record["status"] = f"waiting_for_{arm}"
            atomic_json(recovery_state_path, state_record)
            outcome = execute_arm(arm, args.source, args.gamma, args.dataset, state_record, reservations)
            if outcome.get("status") == "resource_retry_limit_reached":
                state_record["status"] = "resource_retry_limit_reached"
                state_record["retry_limit"] = outcome
                state_record["pending_arms"] = [arm] + [x for x in pending_arms if x != arm]
                state_record["updated"] = time.time()
                atomic_json(recovery_state_path, state_record)
                print(json.dumps({"status": state_record["status"],
                                  "pending_arms": state_record["pending_arms"],
                                  "attempt_count": len(state_record["attempts"])}, indent=2))
                return
        # Revalidate original arms and both fresh results before creating receipt.
        for arm in EXPECTED_ARMS:
            if not old_queue.valid_result(arm, OUT / arm):
                raise AssertionError(f"previously completed arm no longer validates: {arm}")
        new = [row for row in state_record["attempts"] if row.get("status") == "complete"]
        if [row.get("arm") for row in new] != list(REMAINING_ARMS):
            raise AssertionError("both requested recovery arms have not completed in order")
        state_record["status"] = "complete_isolated_recovery"
        state_record["completed"] = time.time()
        atomic_json(recovery_state_path, state_record)
        receipt = {"experiment": "SW0108", "status": "two_remaining_arms_complete",
                   "original_queue_state_sha256": sha(args.state),
                   "original_queue_state_modified": False,
                   "source_sha256": state["source_sha256"], "gamma_sha256": state["gamma_sha256"],
                   "prior_completed_arms_valid": list(EXPECTED_ARMS),
                   "recovered_arms": [{"arm": row["arm"], "attempt_id": row["attempt_id"],
                                       "output_dir": row["output_dir"],
                                       "evaluation_sha256": sha(Path(row["output_dir"]) / "evaluation.json"),
                                       "diagnostics_sha256": sha(Path(row["output_dir"]) / "diagnostics_gt_free.json")}
                                      for row in new],
                   "generated_from_recovery_state_sha256": sha(recovery_state_path),
                   "completed": time.time()}
        atomic_json(receipt_path, receipt)
        print(json.dumps({"status": receipt["status"], "receipt": str(receipt_path)}, indent=2))
    except Exception as exc:
        state_record["status"] = "blocked_or_failed"
        state_record["error"] = f"{type(exc).__name__}: {exc}"
        state_record["updated"] = time.time()
        atomic_json(recovery_state_path, state_record)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", type=Path, default=STATE)
    parser.add_argument("--source", type=Path, default=SOURCE_DEFAULT)
    parser.add_argument("--gamma", type=Path, default=GAMMA_DEFAULT)
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--expected-108-parent", type=int, default=EXPECTED_108_PARENT)
    parser.add_argument("--expected-108-worker", type=int, default=EXPECTED_ACTIVE["pid"])
    parser.add_argument("--expected-109-parent", type=int, default=EXPECTED_109_PARENT)
    parser.add_argument("--run", action="store_true", help="execute after separate review")
    parser.add_argument("--resume", action="store_true",
                        help="resume only a preserved resource_retry_limit_reached state after review")
    args = parser.parse_args()
    run_recovery(args)


if __name__ == "__main__":
    main()
